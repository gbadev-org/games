
Licenses applied to `bg_splash1` and `bg_splash2`.

## Copyright
(C) 2021 Guyeon Yu (copyrat90@gmail.com)

## License
CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0)

# Graphic assets license

This applies to all the graphics in the `graphics/` and `graphics_source/` folder, except for the `font_*` ones, and `bg_splash*` ones.

Fonts and `bg_splash*` ones have a seperate license files instead.

## Copyright
(C) 2021 Guyeon Yu (copyrat90@gmail.com)

## License
CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0)

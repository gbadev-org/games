---------------------
CHOCOLATE HUNTER RUNA
---------------------

Developed by Lsh Games (Runa457)


Sequencial battle simulator game for GBA.
You can select enemies to fight, and use various strategies to defeat them.

This game is made with Butano 10.5.0.
https://github.com/GValiente/butano

Source codes are available in the GitHub repository.
https://github.com/Runa457/chocolate_hunter_runa


---------------------


Thanks for downloading my game.

As the first game I made and first submission, it's unfortunate for me that I couldn't make it as much as I planned.
But I'm still satisfied that I can submit my game.
Developing GBA game was quite a difficult but fun experience.
I hope I can do better next time based on this experience.

Anyway, have a good time.
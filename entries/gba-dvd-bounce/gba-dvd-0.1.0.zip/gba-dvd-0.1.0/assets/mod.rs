
pub mod diamond;
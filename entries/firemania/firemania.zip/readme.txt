####################################
#      Welcome to Firemania        #
####################################

Watch your screen burn.
Even with interactive lights when pressing the A button.

Featuring full motion bitmap graphics at 30 fps.

~THE END~

Source code available at:

 - https://github.com/ipatix/gba-template/tree/example/bitmap_fire

Licensed under GPLv3

Using libgba from devkitpro. See its license file for details.
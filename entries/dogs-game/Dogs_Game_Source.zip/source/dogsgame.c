#include <maxmod.h>
#include <stdio.h>
#include <gba.h>
#include "gfx.h"
#include "command.h"

#include "soundbank.h"
#include "soundbank_bin.h"

u16 GAME_STATE = 0;
u16 SPR_OFFS = 0;
u32 GAME_TICKS = 0;

u8 fenceDelay = 20;
u32 fenceCurTick = 0;
u32 fencePrevTick = 0;

u8 cloudDelay = 3;
u32 cloudCurTick = 0;
u32 cloudPrevTick = 0;
u8 cloudX = 0;

u8 dogCommandDelay = 40;

u32 dog1CurTick = 0;
u32 dog2CurTick = 0;
u32 dog3CurTick = 0;
u32 dog4CurTick = 0;

u32 dog1PrevTick = 0;
u32 dog2PrevTick = 0;
u32 dog3PrevTick = 0;
u32 dog4PrevTick = 0;

u16 dog1Button = 8;
u16 dog2Button = 8;
u16 dog3Button = 8;
u16 dog4Button = 8;

u32 randseed = 947;

//key states
int keys_pressed, keys_released;

int main();
int loadBGs(u8 scene);
int loadSprites(u8 scene);
void loadBGPal(u8 pal, const u16* paldata, u8 paldatalen);
void loadBGData(u8 charbase, const u16* bgdata, u16 datalen);
void loadBGMap(u8 pal, u8 screenbase, const u16* bgmap, u16 datalen);
void loadSpritePal(u8 pal, const u16* paldata, u8 paldatalen);
void loadSpriteData(const u16* data, u16 datalen);
void hideAllSprites();
void hideSprite(u8);
void showSprite(u8);
void showScore(u16 s);
void moveSpriteTo(u8 i, u8 x, u8 y);
void setSpriteImg(u8 sprite, u16 tile);

bool readyForCommand(u8 dog);

int doIntro();
int doTitle();
int doCredits();
int doGame();

void pauseState();

void cloudScroll();
void bushRustle();
u32 rng();

u32 rng(){
	u32 a = 197;
	u32 b = 421;
	u32 m = 10321;
	randseed = (a * randseed + b) % m;
	return randseed;
}

bool readyForCommand(u8 dog){
	switch(dog){
		case 1:
			//has enough time gone by
			if(dog1CurTick - dog1PrevTick >= dogCommandDelay){
				//does the dog have a command
				if(dog1Button == 8){
					if(rng()%2==0){
						showSprite(BUTTON1);
						dog1Button = BUTTON_A + ((rng()%8)*16);
						setSpriteImg(BUTTON1,dog1Button);
						setSpriteImg(DOGHEAD1,GSD_MOUTH_OPEN);
						
						return true;
					}
				}
			}
			else{
				dog1CurTick = GAME_TICKS;
			}
			break;
			
		case 2:
			//has enough time gone by
			if(dog2CurTick - dog2PrevTick >= dogCommandDelay){
				//does the dog have a command
				if(dog2Button == 8){
					if(rng()%2==0){
						showSprite(BUTTON2);
						dog2Button = BUTTON_A + ((rng()%8)*16);
						setSpriteImg(BUTTON2,dog2Button);
						setSpriteImg(DOGHEAD2,GSD_MOUTH_OPEN);
						
						return true;
					}
				}
			}
			else{
				dog2CurTick = GAME_TICKS;
			}
			break;
			
		case 3:
			//has enough time gone by
			if(dog3CurTick - dog3PrevTick >= dogCommandDelay){
				//does the dog have a command
				if(dog3Button == 8){
					if(rng()%2==0){
						showSprite(BUTTON3);
						dog3Button = BUTTON_A + ((rng()%8)*16);
						setSpriteImg(BUTTON3,dog3Button);
						setSpriteImg(DOGHEAD3,GSD_MOUTH_OPEN);
						
						return true;
					}
				}
			}
			else{
				dog3CurTick = GAME_TICKS;
			}
			break;
			
		case 4:
			//has enough time gone by
			if(dog4CurTick - dog4PrevTick >= dogCommandDelay){
				//does the dog have a command
				if(dog4Button == 8){
					if(rng()%2==0){
						showSprite(BUTTON4);
						dog4Button = BUTTON_A + ((rng()%8)*16);
						setSpriteImg(BUTTON4,dog4Button);
						setSpriteImg(DOGHEAD4,GSD_MOUTH_OPEN);
						
						return true;
					}
				}
			}
			else{
				dog4CurTick = GAME_TICKS;
			}
			break;
	}
	
	
	return false;
}

void setSpriteImg(u8 sprite, u16 tile){
	OAM[sprite].attr2 &= ((1<<6)-1)<<10;
	OAM[sprite].attr2 |= tile;
}

void pauseState(){
	bool paused = true;
	REG_TM2CNT_H = 0;
	
	showSprite(PAUSE1);
	showSprite(PAUSE2);
	
	showSprite(RESUME1);
	showSprite(RESUME2);
	
	showSprite(QUIT1);
	showSprite(QUIT2);
	
	showSprite(UNDERLINE);
	
	while(paused){
		VBlankIntrWait();
		scanKeys();

		keys_pressed = keysDown();
		keys_released = keysUp();
		
		if(keys_released & KEY_START){
			paused = false;
		}
		
		if ( (keys_released & KEY_DOWN) | (keys_released & KEY_UP) ) {
			if((OAM[UNDERLINE].attr0 & 255) == 106){
				moveSpriteTo(UNDERLINE,104,81);
			}
			else{
				moveSpriteTo(UNDERLINE,104,106);
			}
		}
		
		if(keys_released & KEY_A){
			if((OAM[UNDERLINE].attr0 & 255) == 106){
				GAME_STATE = 1;
				main();
			}
			else{
				paused = false;
				REG_TM2CNT_H = 3 | TIMER_START | TIMER_IRQ;
			}
		}
	}
	
	hideSprite(PAUSE1);
	hideSprite(PAUSE2);
	
	hideSprite(RESUME1);
	hideSprite(RESUME2);
	
	hideSprite(QUIT1);
	hideSprite(QUIT2);
	
	hideSprite(UNDERLINE);
	
	REG_TM2CNT_H = 3 | TIMER_START | TIMER_IRQ;
	
	return;
	
}

void tick(){
	GAME_TICKS += 1;
	return;
}

void showScore(u16 s){
	u8 d1 = CHAR0 + ((s % 10)*4);
	u8 d2 = CHAR0 + (((s/10)%10)*4);
	u8 d3 = CHAR0 + (((s/100)%10)*4);
	u8 d4 = CHAR0 + (((s/1000)%10)*4);
	
	OAM[SCORE1] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(176),OBJ_CHAR(d4)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
	OAM[SCORE2] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(192),OBJ_CHAR(d3)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
	OAM[SCORE3] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(208),OBJ_CHAR(d2)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
	OAM[SCORE4] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(224),OBJ_CHAR(d1)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};

	return;
}

void cloudScroll(){
	if(cloudCurTick - cloudPrevTick >= cloudDelay){
		cloudX += 1;
		REG_BG1HOFS = cloudX;
		cloudPrevTick = cloudCurTick;
	}
	else{
		cloudCurTick = GAME_TICKS;
	}
	
	return;
}

void bushRustle(){
	if(fenceCurTick - fencePrevTick >= fenceDelay){
		if(REG_DISPCNT & BG3_ON){
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|OBJ_ON|OBJ_1D_MAP);
		}
		else{
			SetMode(MODE_0|BG0_ON|BG1_ON|BG3_ON|OBJ_ON|OBJ_1D_MAP);
		}
		
		fencePrevTick = fenceCurTick;
	}
	else{
		fenceCurTick = GAME_TICKS;
	}
	
	return;
}

int loadBGs(u8 scene){
	switch(scene){
		case 0:
			//set mode to 0 with bg0 on
			SetMode(MODE_0);
			loadBGPal(0,osa_pal,OSA_PALLEN);
			loadBGData(0,osa_data,OSA_DATALEN);
			loadBGMap(0,10,osa_map,OSA_MAPLEN);
			REG_BG0CNT = SCREEN_BASE(10);
			SetMode(MODE_0|BG0_ON);
			
			break;
		case 1:
			//set mode to 0 with bg0 on
			//SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON);
			SetMode(MODE_0);
			
			//load intro bg palette
			
			loadBGPal(0,sky_pal,SKY_PALLEN);
			loadBGPal(1,clouds_pal,CLOUDS_PALLEN);
			loadBGPal(2,Fence1_pal,FENCE1_PALLEN);
			loadBGPal(3,Fence2_pal,FENCE2_PALLEN);
			
			loadBGData(0,sky_data,SKY_DATALEN);
			loadBGData(1,clouds_data,CLOUDS_DATALEN);
			loadBGData(2,Fence1_data,FENCE1_DATALEN);
			loadBGData(3,Fence2_data,FENCE2_DATALEN);
			
			loadBGMap(0,7,sky_map,SKY_MAPLEN);
			loadBGMap(1,15,clouds_map,CLOUDS_MAPLEN);
			loadBGMap(2,23,Fence1_map,FENCE1_MAPLEN);
			loadBGMap(3,31,Fence2_map,FENCE2_MAPLEN);
			
			REG_BG0CNT = SCREEN_BASE(7) | CHAR_BASE(0) | BG_PRIORITY(3);
			REG_BG1CNT = SCREEN_BASE(15) | CHAR_BASE(1)| BG_PRIORITY(2);
			REG_BG2CNT = SCREEN_BASE(23) | CHAR_BASE(2)| BG_PRIORITY(1);
			REG_BG3CNT = SCREEN_BASE(31) | CHAR_BASE(3)| BG_PRIORITY(0);
			
			REG_BG3VOFS = -100;
			REG_BG2VOFS = -100;
			
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON);
			
			break;
		default:
			//set mode to 0 with bg0 on
			//SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON);
			SetMode(MODE_0);
			
			//load intro bg palette
			
			loadBGPal(0,sky_pal,SKY_PALLEN);
			loadBGPal(1,clouds_pal,CLOUDS_PALLEN);
			loadBGPal(2,Fence1_pal,FENCE1_PALLEN);
			loadBGPal(3,Fence2_pal,FENCE2_PALLEN);
			
			loadBGData(0,sky_data,SKY_DATALEN);
			loadBGData(1,clouds_data,CLOUDS_DATALEN);
			loadBGData(2,Fence1_data,FENCE1_DATALEN);
			loadBGData(3,Fence2_data,FENCE2_DATALEN);
			
			loadBGMap(0,7,sky_map,SKY_MAPLEN);
			loadBGMap(1,15,clouds_map,CLOUDS_MAPLEN);
			loadBGMap(2,23,Fence1_map,FENCE1_MAPLEN);
			loadBGMap(3,31,Fence2_map,FENCE2_MAPLEN);
			
			REG_BG0CNT = SCREEN_BASE(7) | CHAR_BASE(0) | BG_PRIORITY(3);
			REG_BG1CNT = SCREEN_BASE(15) | CHAR_BASE(1)| BG_PRIORITY(2);
			REG_BG2CNT = SCREEN_BASE(23) | CHAR_BASE(2)| BG_PRIORITY(1);
			REG_BG3CNT = SCREEN_BASE(31) | CHAR_BASE(3)| BG_PRIORITY(0);
			
			REG_BG3VOFS = -100;
			REG_BG2VOFS = -100;
			
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON);
			
			break;
	}
	
	return 0;
}

int loadSprites(u8 scene){
	SPR_OFFS = 0;
	
	switch(scene){
		case 0://title screen
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON|OBJ_1D_MAP);
			
			loadSpritePal(0,Dogs_Game_pal, DOGS_GAME_PALLEN);
			loadSpriteData(Dogs_Game_data,DOGS_GAME_DATALEN);
			
			//Dogs Game
			OAM[DG1] = (OBJATTR){ATTR0_WIDE|OBJ_Y(24),OBJ_SIZE(3) | OBJ_X(24),OBJ_CHAR(0)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[DG2] = (OBJATTR){ATTR0_WIDE|OBJ_Y(24),OBJ_SIZE(3) | OBJ_X(88),OBJ_CHAR(32)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[DG3] = (OBJATTR){ATTR0_WIDE|OBJ_Y(24),OBJ_SIZE(3) | OBJ_X(152),OBJ_CHAR(64)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//Play
			OAM[PLAY1] = (OBJATTR){ATTR0_WIDE|OBJ_Y(64),OBJ_SIZE(2) | OBJ_X(88),OBJ_CHAR(96)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[PLAY2] = (OBJATTR){ATTR0_WIDE|OBJ_Y(64),OBJ_SIZE(2) | OBJ_X(120),OBJ_CHAR(104)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//Credits
			OAM[CRED1] = (OBJATTR){ATTR0_WIDE|OBJ_Y(90),OBJ_SIZE(2) | OBJ_X(72),OBJ_CHAR(112)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[CRED2] = (OBJATTR){ATTR0_WIDE|OBJ_Y(90),OBJ_SIZE(2) | OBJ_X(104),OBJ_CHAR(120)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[CRED3] = (OBJATTR){ATTR0_WIDE|OBJ_Y(90),OBJ_SIZE(2) | OBJ_X(136),OBJ_CHAR(128)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//underline
			OAM[UNDERLINE] = (OBJATTR){ATTR0_WIDE|OBJ_Y(81),OBJ_SIZE(2) | OBJ_X(104),OBJ_CHAR(176)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			hideAllSprites();
			showSprite(DG1);
			showSprite(DG2);
			showSprite(DG3);
			showSprite(PLAY1);
			showSprite(PLAY2);
			showSprite(CRED1);
			showSprite(CRED2);
			showSprite(CRED3);
			showSprite(UNDERLINE);
			
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON|OBJ_ON|OBJ_1D_MAP);
			
			break;
		case 1://dogs game screen
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON|OBJ_1D_MAP);
			
			loadSpritePal(0,Dogs_Game_pal, DOGS_GAME_PALLEN);
			loadSpritePal(1,GSD_pal, GSD_PALLEN);
			loadSpritePal(2,buttons_pal,BUTTONS_PALLEN);
			loadSpritePal(3,skull_pal,SKULL_PALLEN);
			loadSpritePal(4,dog_pal,DOG_PALLEN);
			
			loadSpriteData(Dogs_Game_data,DOGS_GAME_DATALEN);
			loadSpriteData(GSD_data,GSD_DATALEN);
			loadSpriteData(buttons_data,BUTTONS_DATALEN);
			loadSpriteData(skull_data,SKULL_DATALEN);
			loadSpriteData(dog_data,DOG_DATALEN);
			
			//score digits
			OAM[SCORE1] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(176),OBJ_CHAR(CHAR0)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[SCORE2] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(192),OBJ_CHAR(CHAR0)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[SCORE3] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(208),OBJ_CHAR(CHAR0)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[SCORE4] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),OBJ_SIZE(1) | OBJ_X(224),OBJ_CHAR(CHAR0)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//underline
			OAM[UNDERLINE] = (OBJATTR){ATTR0_WIDE|OBJ_Y(81),OBJ_SIZE(2) | OBJ_X(104),OBJ_CHAR(176)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//Paused
			OAM[PAUSE1] = (OBJATTR){ATTR0_WIDE|OBJ_Y(24),OBJ_SIZE(2) | OBJ_X(88),OBJ_CHAR(184)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[PAUSE2] = (OBJATTR){ATTR0_WIDE|OBJ_Y(24),OBJ_SIZE(2) | OBJ_X(120),OBJ_CHAR(192)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//Resume
			//maybe use fewer sprite entries by swapping the tile for play button here...
			OAM[RESUME1] = (OBJATTR){ATTR0_WIDE|OBJ_Y(64),OBJ_SIZE(2) | OBJ_X(88),OBJ_CHAR(200)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[RESUME2] = (OBJATTR){ATTR0_WIDE|OBJ_Y(64),OBJ_SIZE(2) | OBJ_X(120),OBJ_CHAR(208)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//quit
			//same as resume...swap out credits
			OAM[QUIT1] = (OBJATTR){ATTR0_WIDE|OBJ_Y(90),OBJ_SIZE(2) | OBJ_X(96),OBJ_CHAR(216)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			OAM[QUIT2] = (OBJATTR){ATTR0_WIDE|OBJ_Y(90),OBJ_SIZE(2) | OBJ_X(128),OBJ_CHAR(224)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//Game over
			OAM[GAME_OVER] = (OBJATTR){ATTR0_WIDE|OBJ_Y(24),OBJ_SIZE(3) | OBJ_X(24),OBJ_CHAR(232)|OBJ_PRIORITY(0)|OBJ_PALETTE(0),0};
			
			//skulls
			OAM[SKULL1] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),ATTR1_SIZE_16 | OBJ_X(0),OBJ_CHAR(584)|OBJ_PRIORITY(0)|OBJ_PALETTE(3),0};
			OAM[SKULL2] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),ATTR1_SIZE_16 | OBJ_X(16),OBJ_CHAR(584)|OBJ_PRIORITY(0)|OBJ_PALETTE(3),0};
			OAM[SKULL3] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(0),ATTR1_SIZE_16 | OBJ_X(32),OBJ_CHAR(584)|OBJ_PRIORITY(0)|OBJ_PALETTE(3),0};
			
			//button callouts
			OAM[BUTTON1] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(30),ATTR1_SIZE_32 | OBJ_X(16),OBJ_CHAR(456)|OBJ_PRIORITY(0)|OBJ_PALETTE(2),0};
			OAM[BUTTON2] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(30),ATTR1_SIZE_32 | OBJ_X(72),OBJ_CHAR(456)|OBJ_PRIORITY(0)|OBJ_PALETTE(2),0};
			OAM[BUTTON3] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(30),ATTR1_SIZE_32 | OBJ_X(136),OBJ_CHAR(456)|OBJ_PRIORITY(0)|OBJ_PALETTE(2),0};
			OAM[BUTTON4] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(30),ATTR1_SIZE_32 | OBJ_X(192),OBJ_CHAR(456)|OBJ_PRIORITY(0)|OBJ_PALETTE(2),0};
			
			//GSD Heads
			OAM[DOGHEAD1] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(60),ATTR1_SIZE_64 | OBJ_X(0),OBJ_CHAR(GSD_MOUTH_CLOSED)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			OAM[DOGHEAD2] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(60),ATTR1_SIZE_64 | OBJ_X(56),OBJ_CHAR(GSD_MOUTH_CLOSED)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			OAM[DOGHEAD3] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(60),ATTR1_SIZE_64 | OBJ_X(120),OBJ_CHAR(GSD_MOUTH_CLOSED)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			OAM[DOGHEAD4] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(60),ATTR1_SIZE_64 | OBJ_X(176),OBJ_CHAR(GSD_MOUTH_CLOSED)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			
			//GSD Bodies
			OAM[DOGBODY1] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(96),ATTR1_SIZE_64 | OBJ_X(0),OBJ_CHAR(392)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			OAM[DOGBODY2] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(96),ATTR1_SIZE_64 | OBJ_X(56),OBJ_CHAR(392)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			OAM[DOGBODY3] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(96),ATTR1_SIZE_64 | OBJ_X(120),OBJ_CHAR(392)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			OAM[DOGBODY4] = (OBJATTR){ATTR0_SQUARE|OBJ_Y(96),ATTR1_SIZE_64 | OBJ_X(176),OBJ_CHAR(392)|OBJ_PRIORITY(2)|OBJ_PALETTE(1),0};
			
			hideAllSprites();
			//showSprite(SKULL1);
			//showSprite(SKULL2);
			//showSprite(SKULL3);
			
			showSprite(DOGHEAD1);
			showSprite(DOGHEAD2);
			showSprite(DOGHEAD3);
			showSprite(DOGHEAD4);
			
			showSprite(DOGBODY1);
			showSprite(DOGBODY2);
			showSprite(DOGBODY3);
			showSprite(DOGBODY4);
			
			showSprite(SCORE1);
			showSprite(SCORE2);
			showSprite(SCORE3);
			showSprite(SCORE4);
			
			//showSprite(BUTTON1);
			//showSprite(BUTTON2);
			//showSprite(BUTTON3);
			//showSprite(BUTTON4);
			
			//showSprite(PAUSE1);
			//showSprite(PAUSE2);
			
			//showSprite(RESUME1);
			//showSprite(RESUME2);
			
			//showSprite(QUIT1);
			//showSprite(QUIT2);
			
			//showSprite(UNDERLINE);
			
			SetMode(MODE_0|BG0_ON|BG1_ON|BG2_ON|BG3_ON|OBJ_ON|OBJ_1D_MAP);
			
			break;
		default:
			
			break;
	}
	return 0;
}

void loadBGPal(u8 pal, const u16* paldata, u8 paldatalen){
	for(u8 i = 0; i< paldatalen; i++){
		BG_PALETTE[i+pal*16] = paldata[i];
	}

	return;
}

void loadBGData(u8 charbase, const u16* bgdata, u16 datalen){
	//for(u16 i = 0; i< datalen; i++){
	//	((u16*)(VRAM + (charbase*0x4000)))[i] = bgdata[i];
	//}
	
	DMA1COPY((vu32)bgdata,(vu32)(VRAM + (charbase*0x4000)),0);
	
	return;
}

void loadBGMap(u8 pal, u8 screenbase, const u16* bgmap, u16 datalen){
	for(u16 i = 0; i< datalen; i++){
		((u16*)(VRAM + (screenbase*0x800)))[i] = bgmap[i] | (CHAR_PALETTE(pal));
	}
	
	return;
}

void loadSpritePal(u8 pal, const u16* paldata, u8 paldatalen){
	for(u8 i = 0; i< paldatalen; i++){
		SPRITE_PALETTE[i+pal*16] = paldata[i];
	}

	return;
}

void loadSpriteData(const u16* data, u16 datalen){
	for(u16 i = 0; i< datalen; i++){
		SPRITE_GFX[i+SPR_OFFS] = data[i];
	}
	
	SPR_OFFS += datalen;
	
	return;
}

void hideSprite(u8 i){
	OAM[i].attr0 |= BIT(9);
	
	return;
}

void hideAllSprites(){
	for(int i = 0; i < 128; i++){
		hideSprite(i);
	}
	
	return;
}

void showSprite(u8 i){
	OAM[i].attr0 &= 65023;
	
	return;
}

void moveSpriteTo(u8 i, u8 x, u8 y){
	OAM[i].attr0 &= ((1<<8)-1) << 8;
	OAM[i].attr1 &= ((1<<8)-1) << 8;
	OAM[i].attr0 |= y;
	OAM[i].attr1 |= x;
	
	return;
}

int doCredits(){

	return 0;
}

int doIntro(){
	//display logo for a few seconds and then go to title
	
	//load backgrounds for intro scene
	loadBGs(0);
	
	//set timer for 2 seconds
	REG_TM2CNT_L = -0x4000;
	REG_TM2CNT_H = 3 | TIMER_START;
	REG_TM3CNT_H = TIMER_COUNT | TIMER_START;
	
	while(REG_TM3CNT_L<4){
		//wait
	}
	
	//stop the timers
	REG_TM2CNT_H = 0;
	REG_TM3CNT_H = 0;
	
	GAME_STATE = 1;
	
	return 0;
}

int doTitle(){
	loadBGs(1);
	loadSprites(0);
	
	bool running = true;
	irqInit();

	// Maxmod requires the vblank interrupt to reset sound DMA.
	// Link the VBlank interrupt to mmVBlank, and enable it. 
	irqSet( IRQ_VBLANK, mmVBlank );
	irqSet(IRQ_TIMER2, tick);
	irqEnable(IRQ_VBLANK);
	irqEnable(IRQ_TIMER2);
	// initialise maxmod with soundbank and 8 channels
    mmInitDefault( (mm_addr)soundbank_bin, 8 );
	hideSprite(CRED1);
	hideSprite(CRED2);
	hideSprite(CRED3);
	
	// Start playing module
	mmStart( MOD_DOGS_GAME, MM_PLAY_LOOP );
	
	//game ticks;
	REG_TM2CNT_L = -0x333;
	REG_TM2CNT_H = 3 | TIMER_START | TIMER_IRQ;
	
	while(running == true){
		VBlankIntrWait();
		mmFrame();
	 
		scanKeys();

		keys_pressed = keysDown();
		keys_released = keysUp();
		
		/*
		if ( (keys_released & KEY_DOWN) | (keys_released & KEY_UP) ) {
			if((OAM[UNDERLINE].attr0 & 255) == 106){
				moveSpriteTo(UNDERLINE,104,81);
			}
			else{
				moveSpriteTo(UNDERLINE,104,106);
			}
		}
		*/
		
		if(keys_released & KEY_A){
			mmStop();
			REG_TM0CNT_H = 0;
			REG_TM1CNT_H = 0;
			
			if((OAM[UNDERLINE].attr0 & 255) == 106){
				GAME_STATE = 1;
			}
			else{
				GAME_STATE = 2;
			}
			
			running = false;
		}
		
		cloudScroll();
		bushRustle();
	}

	//GAME_STATE = 2;
	
	return 0;
}

int doGame(){
	loadBGs(1);
	loadSprites(1);
	
	randseed = GAME_TICKS;
	
	bool running = true;
	irqInit();

	// Maxmod requires the vblank interrupt to reset sound DMA.
	// Link the VBlank interrupt to mmVBlank, and enable it. 
	irqSet( IRQ_VBLANK, mmVBlank );
	irqSet(IRQ_TIMER2, tick);
	irqEnable(IRQ_VBLANK);
	irqEnable(IRQ_TIMER2);
	
	//u16 s = 0;
	
	//game ticks;
	REG_TM2CNT_L = -0x333; //timer overflows about 20 times per second
	REG_TM2CNT_H = 3 | TIMER_START | TIMER_IRQ;
	
	while(running){
		VBlankIntrWait();
		scanKeys();

		keys_pressed = keysDown();
		keys_released = keysUp();
		
		if(keys_released & KEY_START){
			pauseState();
		}
		
		cloudScroll();
		bushRustle();
		
		/*
		readyForCommand(1);
		readyForCommand(2);
		readyForCommand(3);
		readyForCommand(4);
		
		if(keys_released & KEY_A){
			if(dog1Button == BUTTON_A){
				hideSprite(BUTTON1);
				setSpriteImg(DOGHEAD1,GSD_MOUTH_CLOSED);
				dog1Button = 8;
				dog1PrevTick = dog1CurTick;
			}
			if(dog2Button == BUTTON_A){
				hideSprite(BUTTON2);
				setSpriteImg(DOGHEAD2,GSD_MOUTH_CLOSED);
				dog2Button = 8;
				dog2PrevTick = dog2CurTick;
			}
			if(dog3Button == BUTTON_A){
				hideSprite(BUTTON3);
				setSpriteImg(DOGHEAD3,GSD_MOUTH_CLOSED);
				dog3Button = 8;
				dog3PrevTick = dog3CurTick;
			}
			if(dog4Button == BUTTON_A){
				hideSprite(BUTTON4);
				setSpriteImg(DOGHEAD4,GSD_MOUTH_CLOSED);
				dog4Button = 8;
				dog4PrevTick = dog4CurTick;
			}
		}
		*/
	}
	
	return 0;
}

int main(){
	
	//switch between states of the game
	while(true){
		switch(GAME_STATE){
			case 0:
				doIntro();
				break;
			case 1:
				doTitle();
				break;
			case 2:
				doGame();
				break;
			case 3:
				doCredits();
				break;
			default:
				doTitle();
				break;
		}
	}

	return 0;
}


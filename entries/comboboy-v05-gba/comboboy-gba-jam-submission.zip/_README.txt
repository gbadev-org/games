Github page for this project: https://github.com/JoeriR/comboboy

Currently the game is just a bag of fighting game mechanics.
Have fun trying to find some combo's :D

Check the file "moveData.h" in the source code to read all the moves you can do.

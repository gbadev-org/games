#ifndef MAIN_C
#define MAIN_C

#include <tonc.h>

//#include <stddef.h>
#include <stdint.h>

#include "gba_renderer.h"

#include "../../comboboy/src/engine.h"
#include "../../comboboy/src/input.h"
#include "../../comboboy/src/buffer.h"
#include "../../comboboy/src/dummy.h"

void init() {
    // Set Video mode and enable objects AND setup for a 4bpp map
    REG_BG0CNT = BG_CBB(0) | BG_SBB(30) | BG_4BPP | BG_REG_32x32;
    REG_DISPCNT = DCNT_OBJ | DCNT_OBJ_1D | DCNT_MODE0 | DCNT_BG0;

    initGbaRenderer();

    initBuffer();
}

uint8_t getInput() {
    // Read gamepad
    key_poll();

    uint8_t inputFromHardware = 0x00;

    // Buttons
    if (key_is_down(KEY_A))
        inputFromHardware += CB_A_BUTTON;
    if (key_is_down(KEY_B))
        inputFromHardware += CB_B_BUTTON;

    // Directions
    if (key_is_down(KEY_RIGHT))
        inputFromHardware += CB_RIGHT_BUTTON;
    if (key_is_down(KEY_LEFT))
        inputFromHardware += CB_LEFT_BUTTON;
    if (key_is_down(KEY_UP))
        inputFromHardware += CB_UP_BUTTON;
    if (key_is_down(KEY_DOWN))
        inputFromHardware += CB_DOWN_BUTTON;

    // GBA Start button
    if (key_is_down(KEY_START))
        inputFromHardware = CB_ALL_BUTTONS;

    return inputFromHardware;
}

int main() {
    init();

    // Enable vblank interrupt for battery efficient vsync
    irq_init(NULL);
	irq_add(II_VBLANK, NULL);

    while (1) {
        uint8_t input = getInput();

        if (input == CB_ALL_BUTTONS)
            resetGame();
        else
            updateGame(input);

        prepareNewOam();

        // Wait V-Sync
        //vid_vsync();    // TODO: Replace with a battery efficient solution (interupts)
        VBlankIntrWait();

        // Render new frame
        updateOam(input);
    }

    return 0;
}

#endif
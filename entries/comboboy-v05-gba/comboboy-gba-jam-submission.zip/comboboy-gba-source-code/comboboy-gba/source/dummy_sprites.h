
//{{BLOCK(dummy_sprites)

//======================================================================
//
//	dummy_sprites, 48x16@4, 
//	+ 12 tiles Metatiled by 2x2 not compressed
//	Total size: 384 = 384
//
//	Time-stamp: 2021-01-05, 02:31:48
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_DUMMY_SPRITES_H
#define GRIT_DUMMY_SPRITES_H

#define dummy_spritesTilesLen 384
extern const unsigned short dummy_spritesTiles[192];

#endif // GRIT_DUMMY_SPRITES_H

//}}BLOCK(dummy_sprites)

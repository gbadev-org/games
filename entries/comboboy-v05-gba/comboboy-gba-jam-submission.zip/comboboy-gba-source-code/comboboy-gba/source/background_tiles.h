
//{{BLOCK(background_tiles)

//======================================================================
//
//	background_tiles, 80x80@4, 
//	+ palette 256 entries, not compressed
//	+ 100 tiles not compressed
//	Total size: 512 + 3200 = 3712
//
//	Time-stamp: 2021-01-05, 02:27:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BACKGROUND_TILES_H
#define GRIT_BACKGROUND_TILES_H

#define background_tilesTilesLen 3200
extern const unsigned short background_tilesTiles[1600];

#define background_tilesPalLen 512
extern const unsigned short background_tilesPal[256];

#endif // GRIT_BACKGROUND_TILES_H

//}}BLOCK(background_tiles)

#ifndef GBA_RENDERER_H
#define GBA_RENDERER_H

void initGbaRenderer();

void prepareNewOam();
void updateOam();

#endif
#ifndef GBA_RENDERER_C
#define GBA_RENDERER_C

#include <tonc.h>
#include <tonc_memdef.h>
#include <stdio.h>

#include "../../comboboy/src/engine.h"
#include "../../comboboy/src/buffer.h"

#include "dummy_sprites.h"
#include "player_sprites.h"
#include "background_tiles.h"
#include "arduboy_font_tiles.h"

#define OAM_BUFFER_SIZE 128

#define DUMMY_SPRITE_COUNT 3
#define DUMMY_SPRITE_DATA_SIZE_SHORT 64

#define PLAYER_SPRITE_COUNT 37
#define PLAYER_SPRITE_DATA_SIZE_SHORT 96

#define TEXT_AREA_TILE_POS_START 0

#define COMBO_DISPLAY_X 16
#define COMBO_DISPLAY_Y 16
#define COMBO_DISPLAY_SPACING 40

OBJ_ATTR obj_buffer[OAM_BUFFER_SIZE];

OBJ_ATTR *playerOamObj = &obj_buffer[0];
OBJ_ATTR *dummyOamObj = &obj_buffer[1];
OBJ_ATTR *fireballOamObj = &obj_buffer[2];

uint32_t playerStartTileId = 1;
uint32_t dummyStartTileId = 20;
uint32_t fireballStartTileId = 10;

uint32_t palleteBank = 0;

// Translate positions of sprites to the center of the GBA's display
int16_t spriteOffsetX = 57;    //240 / 2 - 128 / 2;
int16_t spriteOffsetY = 48;    //160 / 2 - 64 / 2;


// Array of pointers to Dummy Sprites
const uint16_t *dummySprites[DUMMY_SPRITE_COUNT] = { dummy_spritesTiles, dummy_spritesTiles + DUMMY_SPRITE_DATA_SIZE_SHORT, dummy_spritesTiles + DUMMY_SPRITE_DATA_SIZE_SHORT * 2 };
const uint16_t *playerSprites[PLAYER_SPRITE_COUNT] = {};

#define SNPRINTF_BUFFER_SIZE 20
char snprintfBuffer[SNPRINTF_BUFFER_SIZE];

// This is required to prevent garbage graphics from showing up on real hardware
// The mGBA emulator already zeroes out these regions by default
static inline void zeroOutGraphicsRegions() {
    toncset16(&se_mem[30][0], 1, 32 * 32);

    u16 value = 0x0000;
    //toncset16(&tile_mem[4][0], value, 8192);
    toncset16(&tile_mem[0][0], value, 32 * 1024 * 3);
}

static inline void initSpritePointerTables() {
    // init Player sprites
    for (int i = 0; i < PLAYER_SPRITE_COUNT; ++i) {
        playerSprites[i] = player_spritesTiles + (PLAYER_SPRITE_DATA_SIZE_SHORT * i);
    }
}

static inline const uint16_t * getPlayerSpritePointer(CB_Sprite spriteId) {
    int index = spriteId - Sprite_Player_Idle;
    const uint16_t *correctedPlayerSpritePointer = playerSprites[index];

    return correctedPlayerSpritePointer;
}

static inline void setUiTilesInBackgroundLayer() {

    int screenOffset = 7 + 32 * 6;

    // Draw border-ceiling
    for (int i = 0; i < 128 / 8; ++i)
        se_mem[30][i + screenOffset] = 11;

    // Draw border-floor
    for (int i = 0; i < 128 / 8; ++i)
        se_mem[30][i + 32 * 7 + screenOffset] = 12;

    // Draw border-left-wall
    for (int i = 0; i < 64 / 8; ++i)
        se_mem[30][i * 32 + screenOffset] = 13;
    
    // Draw border-left-wall
    for (int i = 0; i < 64 / 8; ++i)
        se_mem[30][i * 32 + 128 / 8 - 1 + screenOffset] = 14;

    // Draw border-corners, order: UL, UR, BL, BR
    se_mem[30][0 + screenOffset] = 15;
    se_mem[30][15 + screenOffset] = 16;
    se_mem[30][32 * 7 + screenOffset] = 17;
    se_mem[30][32 * 7 + 15 + screenOffset] = 18;
}

// Writes on Background layer 0
void writeTextOnBackgroundAt(char* text, int16_t x, int16_t y) {
    static char character = '_';
    uint16_t test = 0x00;
    static int counter = 0;
    counter = 0;

    // Roughly translate x,y pixel location to a nearby tile location
    x /= 8;
    y /= 8;

    while (*text != '\0') {
        character = *text;
        test = (uint16_t) character;

        se_mem[30][TEXT_AREA_TILE_POS_START + counter + x + (y * 32)] = test;

        ++counter;
        ++text;
    }
}

void writeIntOnBackgroundAt(int number, int16_t x, int16_t y) {
    snprintf(snprintfBuffer, SNPRINTF_BUFFER_SIZE, "%d", number);
    writeTextOnBackgroundAt(snprintfBuffer, x, y);
}

void initGbaRenderer() {
    zeroOutGraphicsRegions();

    initSpritePointerTables();

    // Init OAM
    oam_init(obj_buffer, OAM_BUFFER_SIZE);

    // Copy fireball tiles
    tonccpy(&tile_mem[4][fireballStartTileId], getPlayerSpritePointer(Sprite_Player_Move_2B_Active), PLAYER_SPRITE_DATA_SIZE_SHORT * 2);

    // Copy UI tiles
    tonccpy(&tile_mem[0][0], background_tilesTiles, background_tilesTilesLen);

    // Copy Font tiles
    tonccpy(&tile_mem[0][0 + ' '], arduboy_font_tilesTiles, arduboy_font_tilesTilesLen);

    // Copy palette
    tonccpy(pal_bg_mem, background_tilesPal, background_tilesPalLen);

    // Copy palette data to VRAM
    tonccpy(pal_obj_mem, player_spritesPal, player_spritesPalLen);

    // Set OAM attributes
    obj_set_attr(playerOamObj, ATTR0_TALL, ATTR1_SIZE_16x32, ATTR2_PALBANK(palleteBank) | playerStartTileId);
    obj_set_attr(dummyOamObj, ATTR0_SQUARE, ATTR1_SIZE_16x16, ATTR2_PALBANK(palleteBank) | dummyStartTileId);
    obj_set_attr(fireballOamObj, ATTR0_TALL, ATTR1_SIZE_16x32, ATTR2_PALBANK(palleteBank) | fireballStartTileId);

    // Set background
    setUiTilesInBackgroundLayer();

    // Draw version info at the bottom of the screen
    writeTextOnBackgroundAt("Comboboy version 0.5 indev", 16, 140);
    writeTextOnBackgroundAt("Made by: Joeri_R", 58, 156);

    // Offset background (minus values have to be used in order to move the "window" correctly)
    //REG_BG0HOFS = -spriteOffsetX;
    //REG_BG0VOFS = -spriteOffsetY;
}

static void changeDummySprite() {
    int index = dummy.sprite - Sprite_Dummy_Idle;
    const uint16_t *tilesPointer = dummySprites[index];

    tonccpy(&tile_mem[4][dummyStartTileId], tilesPointer, DUMMY_SPRITE_DATA_SIZE_SHORT * 2);
}

static void renderPlayer() {
    // Change Player's Sprite in VRAM
    const uint16_t *tilesPointer = getPlayerSpritePointer(player.sprite);
    tonccpy(&tile_mem[4][playerStartTileId], tilesPointer, PLAYER_SPRITE_DATA_SIZE_SHORT * 2);
    
    // Flip the Player's oam-object if neccesary
    if ((player.renderEffect == RenderEffect_H_Flip || player.renderEffect == RenderEffect_HV_Flip) == player.direction)
        BIT_SET(playerOamObj->attr1, ATTR1_HFLIP);
    else
        BIT_CLEAR(playerOamObj->attr1, ATTR1_HFLIP);

    if (player.renderEffect == RenderEffect_V_Flip || player.renderEffect == RenderEffect_HV_Flip)
        BIT_SET(playerOamObj->attr1, ATTR1_VFLIP);
    else
        BIT_CLEAR(playerOamObj->attr1, ATTR1_VFLIP);

    // Probably redundant?
    // if (player.renderEffect == RenderEffect_None) {
    //     BIT_CLEAR(playerOamObj->attr1, ATTR1_HFLIP);
    //     BIT_CLEAR(playerOamObj->attr1, ATTR1_VFLIP);
    // }
}

static void handleFireball(Projectile *fireball) {
    obj_set_pos(fireballOamObj, fireball->x + spriteOffsetX, fireball->y + spriteOffsetY);

    if (fireball->direction)
        BIT_CLEAR(fireballOamObj->attr1, ATTR1_HFLIP);
    else
        BIT_SET(fireballOamObj->attr1, ATTR1_HFLIP);
}

static void renderComboDisplay() {
    writeTextOnBackgroundAt("Combo stats:", COMBO_DISPLAY_X, COMBO_DISPLAY_Y - 8);

    writeIntOnBackgroundAt(comboCounterDisplay, COMBO_DISPLAY_X, COMBO_DISPLAY_Y);
    writeTextOnBackgroundAt("Hits", COMBO_DISPLAY_X + COMBO_DISPLAY_SPACING, COMBO_DISPLAY_Y);

    writeIntOnBackgroundAt(comboDamageDisplay, COMBO_DISPLAY_X, COMBO_DISPLAY_Y + 8);
    writeTextOnBackgroundAt("Dmg", COMBO_DISPLAY_X + COMBO_DISPLAY_SPACING, COMBO_DISPLAY_Y + 8);

    writeIntOnBackgroundAt(currentHitDamage, COMBO_DISPLAY_X, COMBO_DISPLAY_Y + 16);
    writeTextOnBackgroundAt("Dmg hit", COMBO_DISPLAY_X + COMBO_DISPLAY_SPACING, COMBO_DISPLAY_Y + 16);
}

static void clearComboDisplay() {
    static char clearText[] = "            ";
    writeTextOnBackgroundAt(clearText, COMBO_DISPLAY_X, COMBO_DISPLAY_Y - 8);
    writeTextOnBackgroundAt(clearText, COMBO_DISPLAY_X, COMBO_DISPLAY_Y);
    writeTextOnBackgroundAt(clearText, COMBO_DISPLAY_X, COMBO_DISPLAY_Y + 8);
    writeTextOnBackgroundAt(clearText, COMBO_DISPLAY_X, COMBO_DISPLAY_Y + 16);
}

void prepareNewOam() {

}

void updateOam(uint8_t input) {
    //tonccpy(pal_bg_mem, 0xFFFF, 2);

    // DEBUG
    //debug_scrollBackground(input);

    changeDummySprite();
    renderPlayer();
    handleFireball(fireballPtr);

    // Update Player and dummy's positions
    obj_set_pos(playerOamObj, player.x + spriteOffsetX - 1, player.y + spriteOffsetY);
    obj_set_pos(dummyOamObj, dummy.x + spriteOffsetX - 1, dummy.y + spriteOffsetY);

    // Handle Player and dummy direction
    if (player.direction) {
        //BIT_CLEAR(playerOamObj->attr1, ATTR1_HFLIP);
        BIT_SET(dummyOamObj->attr1, ATTR1_HFLIP);
    }
    else {
        //BIT_SET(playerOamObj->attr1, ATTR1_HFLIP);
        BIT_CLEAR(dummyOamObj->attr1, ATTR1_HFLIP);
    }

    // Handle combo display
    if (comboDisplayTimer < comboDisplayTimerLimit)
        renderComboDisplay();
    else
        clearComboDisplay();

    // Print special motion detection
    if (checkQuarterCircleForward()) 
        writeTextOnBackgroundAt("Motion: QCF", 128, 16);
    else if (checkQuarterCircleBack())
        writeTextOnBackgroundAt("Motion: QCB", 128, 16);
    else
        writeTextOnBackgroundAt("           ", 128, 16);

    oam_copy(oam_mem, obj_buffer, OAM_BUFFER_SIZE);
}

#endif
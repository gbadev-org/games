
//{{BLOCK(arduboy_font_tiles)

//======================================================================
//
//	arduboy_font_tiles, 80x80@4, 
//	+ palette 16 entries, not compressed
//	+ 100 tiles not compressed
//	Total size: 32 + 3200 = 3232
//
//	Time-stamp: 2021-01-09, 21:49:27
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ARDUBOY_FONT_TILES_H
#define GRIT_ARDUBOY_FONT_TILES_H

#define arduboy_font_tilesTilesLen 3200
extern const unsigned short arduboy_font_tilesTiles[1600];

#define arduboy_font_tilesPalLen 32
extern const unsigned short arduboy_font_tilesPal[16];

#endif // GRIT_ARDUBOY_FONT_TILES_H

//}}BLOCK(arduboy_font_tiles)

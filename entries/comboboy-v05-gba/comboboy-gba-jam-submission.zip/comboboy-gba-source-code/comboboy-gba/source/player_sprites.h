
//{{BLOCK(player_sprites)

//======================================================================
//
//	player_sprites, 192x192@4, 
//	+ palette 256 entries, not compressed
//	+ 576 tiles Metatiled by 2x3 not compressed
//	Total size: 512 + 18432 = 18944
//
//	Time-stamp: 2021-01-05, 02:29:56
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PLAYER_SPRITES_H
#define GRIT_PLAYER_SPRITES_H

#define player_spritesTilesLen 18432
extern const unsigned short player_spritesTiles[9216];

#define player_spritesPalLen 512
extern const unsigned short player_spritesPal[256];

#endif // GRIT_PLAYER_SPRITES_H

//}}BLOCK(player_sprites)

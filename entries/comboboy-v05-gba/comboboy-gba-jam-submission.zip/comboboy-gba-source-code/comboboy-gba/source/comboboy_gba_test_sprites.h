
//{{BLOCK(comboboy_gba_test_sprites)

//======================================================================
//
//	comboboy_gba_test_sprites, 64x72@4, 
//	+ palette 16 entries, not compressed
//	+ 72 tiles Metatiled by 2x3 not compressed
//	Total size: 32 + 2304 = 2336
//
//	Time-stamp: 2020-12-31, 18:29:39
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COMBOBOY_GBA_TEST_SPRITES_H
#define GRIT_COMBOBOY_GBA_TEST_SPRITES_H

#define comboboy_gba_test_spritesTilesLen 2304
extern const unsigned short comboboy_gba_test_spritesTiles[1152];

#define comboboy_gba_test_spritesPalLen 32
extern const unsigned short comboboy_gba_test_spritesPal[16];

#endif // GRIT_COMBOBOY_GBA_TEST_SPRITES_H

//}}BLOCK(comboboy_gba_test_sprites)

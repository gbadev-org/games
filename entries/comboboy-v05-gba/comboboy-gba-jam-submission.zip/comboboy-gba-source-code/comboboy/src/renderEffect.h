#ifndef RENDER_EFFECT_H
#define RENDER_EFFECT_H

enum RenderEffects { RenderEffect_None, RenderEffect_H_Flip, RenderEffect_V_Flip, RenderEffect_HV_Flip };
typedef enum RenderEffects RenderEffect;

#endif
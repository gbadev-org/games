#ifndef KNOCKBACK_CPP
#define KNOCKBACK_CPP

#include "knockback.h"
#include "engine.h"

void setKnockback(Knockback *knockback) {
    // Calculate knockback with side switching in mind
    int8_t horizontalDistanceVar = player.direction ? knockback->horizontalDistance : knockback->horizontalDistance * -1;

    dummy.knockback.horizontalDistance = horizontalDistanceVar;   
    dummy.knockback.verticalDistance = knockback->verticalDistance;
    dummy.knockback.ticksPerFrame = knockback->ticksPerFrame;
    dummy.knockback.tickLimit = knockback->tickLimit;
    dummy.knockback.properties = knockback->properties;
    dummy.knockback.knockbackFunction = knockback->knockbackFunction;
}

#endif
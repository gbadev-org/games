#ifndef RENDERER_H
#define RENDERER_H

#include "../sprites.h"

//void renderSprite(CB_Sprite sprite, uint8_t x, uint8_t y);

// TODO: Add more render functions for ex: text, border around screen, etc.

#endif
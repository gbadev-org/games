#ifndef MOVEDATA_H
#define MOVEDATA_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

#include "cinematics/superflash_vertical.h"
#include "cinematics/j_grab_super.h"
#include "engine.h"
#include "knockback.h"
#include "knockbackData.h"
#include "move.h"
#include "projectile.h"
#include "sprites.h"

// Defines
#define CB_DIVEKICK_STARTUP_FRAMES 10

// Move Functions
void moveFunction5B() {
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active) {
        playerMoveForwards(&player, 1);
        player.xOffset = -4;
    }
}

void moveFunction2B() {
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Startup && player.currentMoveFrameCounter % 3 == 0) 
        playerMoveForwards(&player, 1);
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active) 
        playerMoveForwards(&player, 2);
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Recovery && player.currentMoveFrameCounter % 2 == 0) 
        playerMoveForwards(&player, 1);
}

void moveFunction236A() {
    if (!isProjectileOnScreen(fireballPtr) && getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Recovery && player.currentMoveFrameCounter == player.currentMove->startupFrames + player.currentMove->activeFrames + 1) {
        fireballPtr->x = player.x;
        fireballPtr->y = player.y;
        fireballPtr->damage = 12;
        fireballPtr->direction = player.direction;
        fireballPtr->despawnAfterHitstop = false;
    }
}

void moveFunctionHandstandKick() {
    // Set jump direction on frame 2 and disable double jumping
    if (player.currentMoveFrameCounter == 1) {
        player.allowDoubleJump = false;
        
        if (player.direction)
            player.jumpDirection = 1;
        else 
            player.jumpDirection = -1;
    }

    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active) {
        player.x += player.jumpDirection;
        player.y -= 2;
        player.jumpFrame = JUMP_ASCENDING_FRAMES + 1;   // Put and keep the player in an airborne state
    }
    else if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Recovery && player.currentMoveFrameCounter % 4) {
        player.x += player.jumpDirection;
        player.y -= 1;

        // Handle air movement after this move has been finished
        player.jumpFrame = JUMP_ASCENDING_FRAMES + 5;
    }
        
}

// The definition of this function has been moved to the bottom of this file
void moveFunctionJ214A();

void moveFunctionJ214ACharged() {
    // Put the Player in float state during this move's startup
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Startup) 
        player.jumpFrame = JUMP_ASCENDING_FRAMES + JUMP_FLOATING_FRAMES - 3;

    // Put the Player in falling state during this move's active frames
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active) {
        player.jumpFrame = JUMP_ASCENDING_FRAMES + JUMP_FLOATING_FRAMES + 5;
        player.x += player.jumpDirection * 2;
        ++player.y;
    }
}

void moveFunctionJGrabSuper() {
    if (player.currentMoveFrameCounter == 2) {
        playCinematic(&CINEMATIC_SUPERFLASH_1);
    }

    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active) {
        player.jumpFrame = JUMP_ASCENDING_FRAMES + JUMP_FLOATING_FRAMES + 5;
        player.x += player.jumpDirection * 2;
        ++player.y;


        // TODO: Move this collision detection part to it's own function for re-use?
        uint8_t xPositionHitbox;
        if (player.direction)
            xPositionHitbox = player.x + player.currentMove->hitboxData.xOffset;
        else
            xPositionHitbox = player.x + 16 - player.currentMove->hitboxData.xOffset - player.currentMove->hitboxData.width;

        Hitbox playerMoveHitbox = {
            x : xPositionHitbox,
            y : player.y + player.currentMove->hitboxData.yOffset,
            width : player.currentMove->hitboxData.width,
            height : player.currentMove->hitboxData.height
        };

        dummy.hitbox.x = dummy.x;
        dummy.hitbox.y = dummy.y;

        if (dummy.state != DummyState_Recovery && collision(&playerMoveHitbox, &dummy.hitbox)) {
            //handleCurrentMoveHit(player.currentMove);
            playCinematic(&CINEMATIC_J_GRAB_SUPER_START);
        }
    }
}

// Move Data
const Move MOVE_5A = {
    startupFrames: 6,
    activeFrames: 3,
    recoveryFrames: 12,
    hitstunFrames: 24,
    damage: 5,
    startupSprite: Sprite_Player_Move_5A_Startup,
    activeSprite: Sprite_Player_Move_5A_Active,
    recoverySprite: Sprite_Player_Move_5A_Recovery,
    moveFunction: NULL,
    moveProperties: MoveProperty_None,
    knockback: &knockback_weak,
    hitboxData: {
        xOffset: 8,
        yOffset: 0,
        width: 12,
        height: 16
    }
};

const Move MOVE_5B = {
    startupFrames: 12,
    activeFrames: 6,
    recoveryFrames: 20,
    hitstunFrames: 30,
    damage: 10,
    startupSprite: Sprite_Player_Move_5B_Startup,
    activeSprite: Sprite_Player_Move_5B_Active,
    recoverySprite: Sprite_Player_Move_5B_Recovery,
    moveFunction: moveFunction5B,
    moveProperties: MoveProperty_LockDirection,
    knockback: &knockback_5B,
    hitboxData: {
        xOffset: 8,
        yOffset: 0,
        width: 14,
        height: 16
    }
};

const Move MOVE_2A = {
    startupFrames: 7,
    activeFrames: 2,
    recoveryFrames: 11,
    hitstunFrames: 20,
    damage: 5,
    startupSprite: Sprite_Player_Move_2A_Startup,
    activeSprite: Sprite_Player_Move_2A_Active,
    recoverySprite: Sprite_Player_Move_2A_Recovery,
    moveFunction: NULL,
    moveProperties: MoveProperty_None,
    knockback: &knockback_weak,
    hitboxData: {
        xOffset: 12,
        yOffset: 17,
        width: 8,
        height: 7
    }
};

const Move MOVE_2B = {
    startupFrames: 10,
    activeFrames: 8,
    recoveryFrames: 20,
    hitstunFrames: 32,
    damage: 10,
    startupSprite: Sprite_Player_Move_2B_Startup,
    activeSprite: Sprite_Player_Move_2B_Active,
    recoverySprite: Sprite_Player_Move_2B_Recovery,
    moveFunction: moveFunction2B,
    moveProperties: MoveProperty_LockDirection,
    knockback: &knockback_2B,
    hitboxData: {
        xOffset: 6,
        yOffset: 11,
        width: 13,
        height: 13
    }
};

const Move MOVE_236A = {
    startupFrames: 15,
    activeFrames: 2,
    recoveryFrames: 20,
    hitstunFrames: 45,
    damage: 12,
    startupSprite: Sprite_Player_Move_236A_Startup,
    activeSprite: Sprite_Player_Move_236A_Active,
    recoverySprite: Sprite_Player_Move_236A_Recovery,
    moveFunction: moveFunction236A,
    moveProperties: MoveProperty_None,
    knockback: &knockback_236A_fireball,    // Knockback is triggered when the fireball hits the dummy
    hitboxData: {   // 236A launches a fireball that caries a hitbox, the move itself does not
        xOffset: 0,
        yOffset: 0,
        width: 0,
        height: 0
    }
};

const Move MOVE_HANDSTAND_KICK = {
    startupFrames: 10,
    activeFrames: 8,
    recoveryFrames: 24,
    hitstunFrames: 45,
    damage: 12,
    startupSprite: Sprite_Player_Move_Handstand_Kick_Startup,
    activeSprite: Sprite_Player_Move_Handstand_Kick_Active,
    recoverySprite: Sprite_Player_Move_Handstand_Kick_Recovery,
    moveFunction: moveFunctionHandstandKick,
    moveProperties: MoveProperty_None,
    knockback: &knockback_2B,
    hitboxData: {
        xOffset: 0,
        yOffset: 0,
        width: 22,
        height: 28
    }
};

const Move MOVE_J_5A = {
    startupFrames: 6,
    activeFrames: 3,
    recoveryFrames: 12,
    hitstunFrames: 24,
    damage: 5,
    startupSprite: Sprite_Player_Move_J_5A_Startup,
    activeSprite: Sprite_Player_Move_J_5A_Active,
    recoverySprite: Sprite_Player_Move_J_5A_Recovery,
    moveFunction: NULL,
    moveProperties: MoveProperty_None,
    knockback: &knockback_J5A,
    hitboxData: {
        xOffset: 8,
        yOffset: 0,
        width: 14,
        height: 20
    }
};

const Move MOVE_J_5B = {
    startupFrames: 10,
    activeFrames: 6,
    recoveryFrames: 16,
    hitstunFrames: 28,
    damage: 10,
    startupSprite: Sprite_Player_Move_J_5B_Startup,
    activeSprite: Sprite_Player_Move_J_5B_Active,
    recoverySprite: Sprite_Player_Move_J_5B_Recovery,
    moveFunction: NULL,
    moveProperties: MoveProperty_None,
    knockback: &knockback_J5A,
    hitboxData: {
        xOffset: 8,
        yOffset: 10,
        width: 14,
        height: 20
    }
};

// This move is a divekick
// It is active until the Player touches the ground or hits the Dummy and cancels it into something else
// Hold down the A button to charge and perform the charged version instead
const Move MOVE_J_214A = {
    startupFrames: CB_DIVEKICK_STARTUP_FRAMES,
    activeFrames: 250,  // This move stays active until the player lands on the ground
    recoveryFrames: 1,
    hitstunFrames: 32,
    damage: 12,
    startupSprite: Sprite_Player_Move_J_214A_Startup,
    activeSprite: Sprite_Player_Move_J_214A_Active,
    recoverySprite: Sprite_Player_Idle,        // This move has no real recovery
    moveFunction: moveFunctionJ214A,
    moveProperties: MoveProperty_LockDirection | MoveProperty_LockAirDirection | MoveProperty_DoNotAllowDoubleJump,
    knockback: &knockback_J_214A,
    hitboxData: {
        xOffset: 3,
        yOffset: 10,
        width: 13,
        height: 14
    }
};

// This move is a divekick
// It is active until the Player touches the ground or hits the Dummy and cancels it into something else
// This version of the divekick pushes both the Player and the Dummy all the way to the ground
const Move MOVE_J_214A_CHARGED = {
    startupFrames: 18 - CB_DIVEKICK_STARTUP_FRAMES,   // This move can only be executed after the startup of J.214A, therefore those active frames are subtracted here. Total startupframes should be 18
    activeFrames: 250,  // This move stays active until the player lands on the ground
    recoveryFrames: 1,
    hitstunFrames: 64,
    damage: 12,
    startupSprite: Sprite_Player_Move_J_214A_Startup,
    activeSprite: Sprite_Player_Move_J_214A_Active,
    recoverySprite: Sprite_Player_Idle,        // This move has no real recovery
    moveFunction: moveFunctionJ214ACharged,
    moveProperties: MoveProperty_LockDirection | MoveProperty_LockAirDirection | MoveProperty_DoNotAllowDoubleJump,
    knockback: &knockback_J_214A_charged,
    hitboxData: {
        xOffset: 3,
        yOffset: 10,
        width: 13,
        height: 14
    }
};

const Move MOVE_J_GRAB_SUPER = {
    startupFrames: 3,
    activeFrames: 200,
    recoveryFrames: 1,
    hitstunFrames: 250,
    damage: 20,
    startupSprite: Sprite_Player_Move_J_Grab_Super_Startup,
    activeSprite: Sprite_Player_Move_J_Grab_Super_Active,
    recoverySprite: Sprite_Player_Idle,    // This move has no real recovery, just like a divekick
    moveFunction: moveFunctionJGrabSuper,
    moveProperties: MoveProperty_LockDirection | MoveProperty_LockAirDirection | MoveProperty_DoNotAllowDoubleJump,
    knockback: NULL,             // The Super Cinematic handles knockback and hitstun
    hitboxData: {
        xOffset: 3,
        yOffset: 10,
        width: 13,
        height: 14
    }
};

void moveFunctionJ214A() {
    static bool playerIsHoldingA = false;

    if (player.currentMoveFrameCounter == 1) {
        playerIsHoldingA = true;
    }

    // Put the Player in float state during this move's startup
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Startup) {
        player.jumpFrame = JUMP_ASCENDING_FRAMES + JUMP_FLOATING_FRAMES - 3;

        // If the Player is not holding A anymore, set playerIsHoldingA to false
        if (playerIsHoldingA && !(inputCurrentFrame & CB_A_BUTTON))
            playerIsHoldingA = false;

        // If the Player is still holding A on the last startup frame, then execute the instead perform the charged version of this move
        if (playerIsHoldingA && player.currentMoveFrameCounter == CB_DIVEKICK_STARTUP_FRAMES - 1)
            playerExecuteMove(&player, &MOVE_J_214A_CHARGED);
    }

    // Put the Player in falling state during this move's active frames
    if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active) {
        player.jumpFrame = JUMP_ASCENDING_FRAMES + JUMP_FLOATING_FRAMES + 5;
        player.x += player.jumpDirection * 2;
        ++player.y;
    }
};

#ifdef __cplusplus
} // extern "C"
#endif

#endif

/*
// Copy and paste base for convenience:

const Move MOVE_ = {
    startupFrames: ,
    activeFrames: ,
    recoveryFrames: ,
    hitstunFrames: ,
    damage: ,
    startupSprite: PLAYER__STARTUP,
    activeSprite: PLAYER__ACTIVE,
    recoverySprite: PLAYER__RECOVERY,
    moveFunction: NULL,
    knockback: NULL,
    hitboxData: ConstHitbox {
        xOffset: ,
        yOffset: ,
        width: ,
        height: 
    }
};

*/
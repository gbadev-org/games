#ifndef PLAYER_C
#define PLAYER_C

#include <stddef.h>
#include <stdbool.h>

#include "input.h"
#include "player.h"
#include "sprites.h"


void playerSetIdle(Player *player) {
    player->currentMove = NULL;
    player->currentMoveFrameCounter = 0;
    player->state = PlayerState_Idle;
    player->sprite = Sprite_Player_Idle;
}

void playerExecuteMove(Player *player, Move const *move) {
    player->currentMove = move;
    player->currentMoveFrameCounter = 0;
    player->currentMoveHit = false; // CARE:
    player->allowDoubleJump = true;
    player->state = PlayerState_ExecutingMove;
}

void playerMoveForwards(Player *player, uint8_t pixelsForward) {
    if (player->direction)
        player->x += pixelsForward;
    else
        player->x -= pixelsForward;

    playerSyncPositionToHitbox(player);
}

void playerMoveBackwards(Player *player, uint8_t pixelsBackward) {
    if (player->direction)
        player->x -= pixelsBackward;
    else
        player->x += pixelsBackward;

    playerSyncPositionToHitbox(player);
}

void playerSyncPositionToHitbox(Player *player) {
    player->hitbox.x = player->x + PLAYER_HITBOX_X_OFFSET; 
    player->hitbox.y = player->y + PLAYER_HITBOX_Y_OFFSET;
}

// crouchFrame decides the PlayerCrouchState that we're in
PlayerCrouchState getPlayerCrouchState(Player *player, uint8_t input) {
    if (input & CB_DOWN_BUTTON && player->state == PlayerState_Idle && player->crouchFrame < CROUCH_FRAME_LIMIT)
        ++player->crouchFrame;

    if (!(input & CB_DOWN_BUTTON)) {
        if (player->crouchFrame > 0)
            --player->crouchFrame;
    }

    if (player->crouchFrame == 0)
        return PlayerCrouchState_Standing;
    else if (player->crouchFrame == CROUCH_FRAME_LIMIT)
        return PlayerCrouchState_Crouching;
    else
        return PlayerCrouchState_InBetween;
}

PlayerWalkState updatePlayerWalkFrame(Player *player) {
    ++player->walkFrame;

    if (player->walkFrame > WALK_1_FRAMES + WALK_2_FRAMES)
        player->walkFrame = 0;

    if (player->walkFrame < WALK_1_FRAMES) 
        return PlayerWalkState_Walk1;
    else
        return PlayerWalkState_Walk2;
}

PlayerJumpState updatePlayerJumpFrame(Player *player) {
    ++player->jumpFrame;

    if (player->jumpFrame <= JUMP_STARTUP_FRAMES) 
        return PlayerJumpState_Startup;
    else if (player->jumpFrame < JUMP_STARTUP_FRAMES + JUMP_ASCENDING_FRAMES)
        return PlayerJumpState_Ascending;
    else if (player->jumpFrame < JUMP_STARTUP_FRAMES + JUMP_ASCENDING_FRAMES + JUMP_FLOATING_FRAMES)
        return PlayerJumpState_Floating;
    else 
        return PlayerJumpState_Falling;
}

#endif
#ifndef SPRITES_H
#define SPRITES_H

#ifdef __cplusplus
extern "C" {
#endif

enum CB_Sprites { 
    Sprite_None,
    Sprite_Player_Idle,
    Sprite_Player_Walk_1, Sprite_Player_Walk_2,
    Sprite_Player_Crouch_Inbetween, Sprite_Player_Crouch,
    Sprite_Player_Jump_Startup, Sprite_Player_Jump_Ascending, Sprite_Player_Jump_Floating, Sprite_Player_Jump_Falling,
    Sprite_Player_Move_5A_Startup, Sprite_Player_Move_5A_Active, Sprite_Player_Move_5A_Recovery,
    Sprite_Player_Move_5B_Startup, Sprite_Player_Move_5B_Active, Sprite_Player_Move_5B_Recovery,
    Sprite_Player_Move_2A_Startup, Sprite_Player_Move_2A_Active, Sprite_Player_Move_2A_Recovery,
    Sprite_Player_Move_2B_Startup, Sprite_Player_Move_2B_Active, Sprite_Player_Move_2B_Recovery,
    Sprite_Player_Move_236A_Startup, Sprite_Player_Move_236A_Active, Sprite_Player_Move_236A_Recovery,
    Sprite_Player_Move_Handstand_Kick_Startup, Sprite_Player_Move_Handstand_Kick_Active, Sprite_Player_Move_Handstand_Kick_Recovery,
    Sprite_Player_Move_J_5A_Startup, Sprite_Player_Move_J_5A_Active, Sprite_Player_Move_J_5A_Recovery,
    Sprite_Player_Move_J_5B_Startup, Sprite_Player_Move_J_5B_Active, Sprite_Player_Move_J_5B_Recovery,
    Sprite_Player_Move_J_214A_Startup, Sprite_Player_Move_J_214A_Active,
    Sprite_Player_Move_J_Grab_Super_Startup, Sprite_Player_Move_J_Grab_Super_Active,
    Sprite_Dummy_Idle, Sprite_Dummy_Hit, Sprite_Dummy_Recovery,
    Sprite_Superflash_1, Sprite_Superflash_2, Sprite_Superflash_3, Sprite_Superflash_4, Sprite_Superflash_5, Sprite_Superflash_6,
    Sprite_Superflash_1_Horizontal, Sprite_Superflash_2_Horizontal, Sprite_Superflash_3_Horizontal, Sprite_Superflash_4_Horizontal, Sprite_Superflash_5_Horizontal, Sprite_Superflash_6_Horizontal,
};

typedef enum CB_Sprites CB_Sprite;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
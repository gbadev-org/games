#ifndef MOVE_C
#define MOVE_C

#include "move.h"


MoveState getMoveState(Move const *move, uint8_t currentFrame) {
    if (currentFrame < move->startupFrames)
        return MoveState_Startup;
    else if (currentFrame < move->startupFrames + move->activeFrames)
        return MoveState_Active;
    else if (currentFrame < move->startupFrames + move->activeFrames + move->recoveryFrames)
        return MoveState_Recovery;
    else
        return MoveState_Finished;
}

#endif
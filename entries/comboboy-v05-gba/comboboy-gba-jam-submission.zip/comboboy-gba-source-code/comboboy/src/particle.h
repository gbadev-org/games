#ifndef PARTICLE_H
#define PARTICLE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "sprites.h"

typedef struct Particle {
    uint8_t x;
    uint8_t y;
    uint8_t width;
    uint8_t height;
    CB_Sprite sprite;
} Particle;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
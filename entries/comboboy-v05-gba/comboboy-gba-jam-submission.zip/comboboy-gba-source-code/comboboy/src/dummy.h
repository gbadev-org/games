#ifndef DUMMY_H
#define DUMMY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "hitbox.h"
#include "knockback.h"
#include "sprites.h"

#define DUMMY_WIDTH_HEIGHT 16

enum DummyStates { DummyState_Idle, DummyState_Hit, DummyState_Recovery };
typedef enum DummyStates DummyState;

typedef struct Dummy {
    uint8_t x;
    uint8_t y;
    uint8_t stunnedFrames;
    uint8_t recoveryFrames;
    uint8_t knockbackTick;
    DummyState state;
    CB_Sprite sprite;
    Hitbox hitbox;
    Knockback knockback;
} Dummy;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
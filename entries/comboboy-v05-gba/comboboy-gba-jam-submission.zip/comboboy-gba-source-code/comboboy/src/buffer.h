#ifndef BUFFER_H
#define BUFFER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <inttypes.h>
#include <stdbool.h>

void pushIntoBuffer(uint8_t input);
bool detectQuarterCircleForward();
bool detectQuarterCircleBack();

bool checkQuarterCircleForward();
bool checkQuarterCircleBack();

void initBuffer();

void printBufferToSerial();

#ifdef __cplusplus
} // extern "C"
#endif

#endif
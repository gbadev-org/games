#ifndef PLAYER_H
#define PLAYER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "hitbox.h"
#include "move.h"
#include "renderEffect.h"
#include "sprites.h"

#define PLAYER_WIDTH 16
#define PLAYER_HEIGHT 24

#define PLAYER_HITBOX_X_OFFSET 3
#define PLAYER_HITBOX_Y_OFFSET 5

#define CROUCH_FRAME_LIMIT 4

#define WALK_1_FRAMES 4
#define WALK_2_FRAMES 4

#define JUMP_STARTUP_FRAMES 4
#define JUMP_ASCENDING_FRAMES 18
#define JUMP_FLOATING_FRAMES 20

enum PlayerStates { PlayerState_Idle, PlayerState_Dashing, PlayerState_ExecutingMove };
typedef enum PlayerStates PlayerState;

enum PlayerCrouchStates { PlayerCrouchState_Standing, PlayerCrouchState_InBetween, PlayerCrouchState_Crouching };
typedef enum PlayerCrouchStates PlayerCrouchState;

enum PlayerWalkStates { PlayerWalkState_Standing, PlayerWalkState_Walk1, PlayerWalkState_Walk2 };
typedef enum PlayerWalkStates PlayerWalkState;

enum PlayerJumpStates { PlayerJumpState_Standing, PlayerJumpState_Startup, PlayerJumpState_Ascending, PlayerJumpState_Floating, PlayerJumpState_Falling };
typedef enum PlayerJumpStates PlayerJumpState;

typedef struct Player {
    uint8_t x;
    uint8_t y;
    int8_t xOffset;
    int8_t yOffset;
    uint8_t direction;      // 0 for facing left, 1 for facing right
    Move *currentMove;
    uint8_t currentMoveFrameCounter;
    bool currentMoveHit;
    PlayerState state;
    uint8_t crouchFrame;
    uint8_t walkFrame;
    uint8_t jumpFrame;
    int8_t jumpDirection;   // 0 for neutral jump, 1 or -1 for directional jumps
    bool doubleJumpUsed;
    bool allowDoubleJump;
    RenderEffect renderEffect;
    PlayerCrouchState crouchState;
    CB_Sprite sprite;
    Hitbox hitbox;
} Player;

void playerSetIdle(Player *player);
void playerExecuteMove(Player *player, Move const *move);

void playerMoveForwards(Player *player, uint8_t pixelsForward);
void playerMoveBackwards(Player *player, uint8_t pixelsBackward);

void playerSyncPositionToHitbox(Player *player);

PlayerCrouchState getPlayerCrouchState(Player *player, uint8_t input);
PlayerWalkState updatePlayerWalkFrame(Player *player);
PlayerJumpState updatePlayerJumpFrame(Player *player);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
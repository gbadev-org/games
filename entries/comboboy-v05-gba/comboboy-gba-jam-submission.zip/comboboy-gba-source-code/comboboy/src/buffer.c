#ifndef BUFFER_CPP
#define BUFFER_CPP

#define BUFFER_SIZE 20
#define SPECIAL_MOTION_REMEMBER_FRAMES 19

#include <stdio.h>
#include <stddef.h>
#include <stdbool.h>

#include "buffer.h"
#include "input.h"

uint8_t buffer[BUFFER_SIZE] = { 0x00 };

uint8_t *startAddress = NULL;
uint8_t *endAddress = NULL;
uint8_t *bufferStart = NULL;
uint8_t *bufferEnd = NULL;

uint8_t quarterCircleForwardDetectedFrames = 0;
uint8_t quarterCircleBackDetectedFrames = 0;

void initBuffer() {
    startAddress = buffer;
    endAddress = buffer + BUFFER_SIZE - 1;

    bufferStart = startAddress;
    bufferEnd = startAddress;
}

// Increments a pointer, however we set it back to the start of the memory area
//		when it reaches the end of the memory area where the buffer is stored
void incrementBufferPointer(uint8_t **pointer) {
	if (*pointer < endAddress)
		++(*pointer);
	else
		*pointer = startAddress;
}

void pushIntoBuffer(uint8_t input) {
	incrementBufferPointer(&bufferEnd);
    
    // Shift startpointer one address ahead if we have run out of space and have wrapped around
    if (bufferStart == bufferEnd) 
		incrementBufferPointer(&bufferStart);
    
    *bufferEnd = input;
}

bool detectQuarterCircleForward() {
    uint8_t *pointer = bufferStart;

    uint8_t counter = 0;

    bool downFound = false;
    bool downForwardFound = false;
    bool forwardFound = false;

    // If a quartercircle forward was detected in x amount of previous frames, then return true
    if (quarterCircleForwardDetectedFrames > 0) {
        --quarterCircleForwardDetectedFrames;
        return true;
    }

	// Go one spot further than bufferEnd?
    while (pointer != bufferEnd) {
		if (*pointer == CB_DOWN_BUTTON) {
			downFound = true;
			counter = 1;
		}
        else if (downFound && *pointer == CB_DOWN_BUTTON + CB_RIGHT_BUTTON)
            downForwardFound = true;
        else if (downForwardFound && *pointer == CB_RIGHT_BUTTON)
            forwardFound = true;

		incrementBufferPointer(&pointer);

		if (counter > 0)
			++counter;

        if (counter > 15)
            downFound = false;
    }

    if (downFound && downForwardFound && forwardFound) {
        quarterCircleForwardDetectedFrames = SPECIAL_MOTION_REMEMBER_FRAMES;
        return true;
    }
    else
        return false;
}

bool detectQuarterCircleBack() {
    uint8_t *pointer = bufferStart;

    uint8_t counter = 0;

    bool downFound = false;
    bool downBackFound = false;
    bool backFound = false;

    // If a quartercircle back was detected in x amount of previous frames, then return true
    if (quarterCircleBackDetectedFrames > 0) {
        --quarterCircleBackDetectedFrames;
        return true;
    }

	// Go one spot further than bufferEnd?
    while (pointer != bufferEnd) {
		if (*pointer == CB_DOWN_BUTTON) {
			downFound = true;
			counter = 1;
		}
        else if (downFound && *pointer == CB_DOWN_BUTTON + CB_LEFT_BUTTON)
            downBackFound = true;
        else if (downBackFound && *pointer == CB_LEFT_BUTTON)
            backFound = true;

		incrementBufferPointer(&pointer);

		if (counter > 0)
			++counter;

        if (counter > 15)
            downFound = false;
    }

    if (downFound && downBackFound && backFound) {
        quarterCircleBackDetectedFrames = SPECIAL_MOTION_REMEMBER_FRAMES;
        return true;
    }
    else
        return false;
}

bool checkQuarterCircleForward() {
    if (quarterCircleForwardDetectedFrames > 0)
        return true;
    else
        return false;
}

bool checkQuarterCircleBack() {
    if (quarterCircleBackDetectedFrames > 0)
        return true;
    else
        return false;
}

void printBufferToSerial() {
    uint8_t *pointer = bufferStart;

    while (pointer != bufferEnd) {
        
        uint8_t value = *pointer;

        if (pointer == startAddress)
            printf("S_");
        if (pointer == endAddress)
            printf("E_");

        printf("%03d ", value);

        incrementBufferPointer(&pointer);
    }
}

#endif
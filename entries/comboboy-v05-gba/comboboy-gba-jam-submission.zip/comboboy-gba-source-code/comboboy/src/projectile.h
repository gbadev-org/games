#ifndef PROJECTILE_H
#define PROJECTILE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <inttypes.h>
#include <stdbool.h>

#include "hitbox.h"
#include "sprites.h"

typedef struct Projectile {
    uint8_t x;
    uint8_t y;
    uint8_t damage;
    bool direction;
    bool despawnAfterHitstop;
    CB_Sprite sprite;
    Hitbox hitbox;
} Projectile;

extern Projectile *fireballPtr;

void despawnProjectile(Projectile *projectile);
bool isProjectileOnScreen(Projectile *projectile);
void updateFireball(Projectile *fireball);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
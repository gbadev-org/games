#ifndef MOVE_H
#define MOVE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "hitbox.h"
#include "knockback.h"
#include "sprites.h"

enum MoveStates { MoveState_Startup, MoveState_Active, MoveState_Recovery, MoveState_Finished };
typedef enum MoveStates MoveState;

enum MovePropertiesValues { 
    MoveProperty_None = 0b0000000,
    MoveProperty_LockAirDirection = 0b00000001,
    MoveProperty_DoNotAllowDoubleJump = 0b00000010,
    MoveProperty_LockDirection = 0b00000100
};
typedef enum MovePropertiesValues MoveProperties;

typedef struct Move {
    const uint8_t startupFrames;
    const uint8_t activeFrames;
    const uint8_t recoveryFrames;
    const uint8_t hitstunFrames;
    const uint8_t damage;
    CB_Sprite startupSprite;
    CB_Sprite activeSprite;
    CB_Sprite recoverySprite;
    void(*moveFunction)();
    MoveProperties moveProperties;
    Knockback *knockback;
    const ConstHitbox hitboxData;
} Move;

MoveState getMoveState(Move const *move, uint8_t currentFrame);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
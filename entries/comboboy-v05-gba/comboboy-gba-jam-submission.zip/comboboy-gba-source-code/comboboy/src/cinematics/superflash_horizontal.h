#ifndef SUPERFLASH_HORIZONTAL_H
#define SUPERFLASH_HORIZONTAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

#include "cinematic.h"

#include "../engine.h"
#include "../sprites.h"

// Functions
void cinematicFunctionSuperflash1_horizontal() {
    superflash_horizontal.x = player.x;
    superflash_horizontal.y = player.y;
    superflash_horizontal.width = 16;
    superflash_horizontal.height = 9;
    superflash_horizontal.sprite = Sprite_Superflash_1_Horizontal;
}

void cinematicFunctionSuperflash2_horizontal() {
    superflash_horizontal.width = 32;
    superflash_horizontal.height = 18;
    superflash_horizontal.sprite = Sprite_Superflash_2_Horizontal;
}

void cinematicFunctionSuperflash3_horizontal() {
    superflash_horizontal.width = 48;
    superflash_horizontal.height = 9;
    superflash_horizontal.sprite = Sprite_Superflash_3_Horizontal;
}

void cinematicFunctionSuperflash4_horizontal() {
    superflash_horizontal.width = 24;
    superflash_horizontal.height = 9;
    superflash_horizontal.sprite = Sprite_Superflash_4_Horizontal;
}

void cinematicFunctionSuperflash5_horizontal() {
    superflash_horizontal.width = 12;
    superflash_horizontal.height = 7;
    superflash_horizontal.sprite = Sprite_Superflash_5_Horizontal;
}

void cinematicFunctionSuperflash6_horizontal() {
    superflash_horizontal.width = 12;
    superflash_horizontal.height = 5;
    superflash_horizontal.sprite = Sprite_Superflash_6_Horizontal;
}

void cinematicFunctionSuperflashHorizontalCleanup() {
    superflash_horizontal.x = 200;
    superflash_horizontal.y = 200;
    superflash_horizontal.width = 1;
    superflash_horizontal.height = 1;
    superflash_horizontal.sprite = Sprite_None;
}

// Data
Cinematic CINEMATIC_SUPERFLASH_HORIZONTAL_CLEANUP = {
    totalFrames: 1,
    cinematicFunction: cinematicFunctionSuperflashHorizontalCleanup,
    nextCinematic: NULL
};

Cinematic CINEMATIC_SUPERFLASH_6_HORIZONTAL = {
    totalFrames: 5,
    cinematicFunction: cinematicFunctionSuperflash6_horizontal,
    nextCinematic: &CINEMATIC_SUPERFLASH_HORIZONTAL_CLEANUP
};

Cinematic CINEMATIC_SUPERFLASH_5_HORIZONTAL = {
    totalFrames: 1,
    cinematicFunction: cinematicFunctionSuperflash5_horizontal,
    nextCinematic: &CINEMATIC_SUPERFLASH_6_HORIZONTAL
};

Cinematic CINEMATIC_SUPERFLASH_4_HORIZONTAL = {
    totalFrames: 2,
    cinematicFunction: cinematicFunctionSuperflash4_horizontal,
    nextCinematic: &CINEMATIC_SUPERFLASH_5_HORIZONTAL
};

Cinematic CINEMATIC_SUPERFLASH_3_HORIZONTAL = {
    totalFrames: 3,
    cinematicFunction: cinematicFunctionSuperflash3_horizontal,
    nextCinematic: &CINEMATIC_SUPERFLASH_4_HORIZONTAL
};

Cinematic CINEMATIC_SUPERFLASH_2_HORIZONTAL = {
    totalFrames: 3,
    cinematicFunction: cinematicFunctionSuperflash2_horizontal,
    nextCinematic: &CINEMATIC_SUPERFLASH_3_HORIZONTAL
};

Cinematic CINEMATIC_Sprite_Superflash_1_Horizontal = {
    totalFrames: 3,
    cinematicFunction: cinematicFunctionSuperflash1_horizontal,
    nextCinematic: &CINEMATIC_SUPERFLASH_2_HORIZONTAL
};

#ifdef __cplusplus
} // extern "C"
#endif

#endif
#ifndef CINEMATIC_H
#define CINEMATIC_H

#ifdef __cplusplus
extern "C" {
#endif

#include <inttypes.h>

extern uint8_t currentCinematicFrame;

// this is a typedef and a declaration of the struct
typedef struct Cinematic_tag Cinematic;
struct Cinematic_tag {
    uint8_t totalFrames;
    void(*cinematicFunction)();
    Cinematic *nextCinematic;
};

extern Cinematic *currentCinematic;

void playCinematic(Cinematic *cinematic); 

#ifdef __cplusplus
} // extern "C"
#endif

#endif
#ifndef CINEMATIC_CPP
#define CINEMATIC_CPP

#include <stddef.h>

#include "cinematic.h"

uint8_t currentCinematicFrame = 0;
Cinematic* currentCinematic = NULL;

void playCinematic(Cinematic *cinematic) {
    currentCinematic = cinematic;
    currentCinematicFrame = 0;

    //currentCinematic->cinematicFunction();
}

#endif
#ifndef J_GRAB_SUPER_H
#define J_GRAB_SUPER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

#include "cinematic.h"

#include "../engine.h"
#include "../sprites.h"

// DEBUG
#include <stdio.h>

// Functions
// Mirroring is done by shifting the dummy.x when player.direction == 1 (true, facing right)
static void cinematicFunctionJGrabSuperStart() {
    dummy.x = player.x - 16 + (32 * player.direction);
    dummy.y = player.y + 24;

    // Push the player and the Dummy back in-bounds so the Cinematic fits on the screen
    if (currentCinematicFrame == 0) {
        Hitbox playerDummyBox = {};

        playerDummyBox.width = PLAYER_WIDTH + DUMMY_WIDTH_HEIGHT;
        playerDummyBox.height = PLAYER_HEIGHT + DUMMY_WIDTH_HEIGHT;
        playerDummyBox.y = player.y;

        if (player.direction) 
            playerDummyBox.x = player.x;
        else 
            playerDummyBox.x = player.x - DUMMY_WIDTH_HEIGHT - 2;

        // Calculate and apply x,y-offset if necessary
        int8_t xOffset = 0;
        int8_t yOffset = 0;
        
        // Calculate x-offset
        if (playerDummyBox.x < 5)
            xOffset = 5 - playerDummyBox.x;
        else if (playerDummyBox.x > 200)
            xOffset = 255 - playerDummyBox.x;
        else if (playerDummyBox.x + playerDummyBox.width > 128)
            xOffset = (playerDummyBox.x + playerDummyBox.width - 128) * -1;

        // Calculate y-offset
        uint8_t projectedHeight = playerDummyBox.y - DUMMY_WIDTH_HEIGHT;

        if (projectedHeight > 200)
            yOffset = yOffset = 255 - projectedHeight + 2;
        else if (playerDummyBox.y + playerDummyBox.height > 64)
            yOffset = (playerDummyBox.y + playerDummyBox.height - 63) * -1;

        player.x += xOffset;
        dummy.x += xOffset;

        player.y += yOffset;
        dummy.y += yOffset;
    }
}

static void cinematicFunctionJGrabSuper90Degree() {
    dummy.x = player.x + 16 - (32 * player.direction);
    dummy.y = player.y + 24;

    player.renderEffect = RenderEffect_H_Flip;
}

static void cinematicFunctionJGrabSuper180Degree() {
    dummy.x = player.x + 16 - (32 * player.direction);
    dummy.y = player.y - 16;

    player.renderEffect = RenderEffect_HV_Flip;
}

static void cinematicFunctionJGrabSuper270Degree() {
    dummy.x = player.x - 16 + (32 * player.direction);
    dummy.y = player.y - 16;

    player.renderEffect = RenderEffect_V_Flip;
}

static void endSuper() {
    currentCinematic = NULL;
    currentCinematicFrame = 0;

    dummy.stunnedFrames = 1;
}

static void cinematicFunctionJGrabSuperThrow() {
    int8_t direction = player.direction ? 1 : -1;
    uint8_t nextDummyX = dummy.x + (3 * direction);

    // Dummy has reached either the left or right wall, end the cinematic
    if (nextDummyX > 230) {
        dummy.x = 0;
        endSuper();
    }
    else if (nextDummyX >= 128 - dummy.hitbox.width) {      // Dummy has reached the left or right wall
        dummy.x = 128 - dummy.hitbox.width;
        endSuper();
    }
    else {
        dummy.x = nextDummyX;
    }
}

// Data
Cinematic CINEMATIC_J_GRAB_SUPER_THROW = {
    totalFrames: 250,
    cinematicFunction: cinematicFunctionJGrabSuperThrow,
    nextCinematic: NULL
};

Cinematic CINEMATIC_J_GRAB_SUPER_270_DEGREE = {
    totalFrames: 8,
    cinematicFunction: cinematicFunctionJGrabSuper270Degree,
    nextCinematic: &CINEMATIC_J_GRAB_SUPER_THROW
};

Cinematic CINEMATIC_J_GRAB_SUPER_180_DEGREE = {
    totalFrames: 6,
    cinematicFunction: cinematicFunctionJGrabSuper180Degree,
    nextCinematic: &CINEMATIC_J_GRAB_SUPER_270_DEGREE
};

Cinematic CINEMATIC_J_GRAB_SUPER_90_DEGREE = {
    totalFrames: 10,
    cinematicFunction: cinematicFunctionJGrabSuper90Degree,
    nextCinematic: &CINEMATIC_J_GRAB_SUPER_180_DEGREE
};

Cinematic CINEMATIC_J_GRAB_SUPER_START = {
    totalFrames: 15,
    cinematicFunction: cinematicFunctionJGrabSuperStart,
    nextCinematic: &CINEMATIC_J_GRAB_SUPER_90_DEGREE
};

#ifdef __cplusplus
} // extern "C"
#endif

#endif
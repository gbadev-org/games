#ifndef SUPERFLASH_VERTICAL_H
#define SUPERFLASH_VERTICAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cinematic.h"

#include "../engine.h"
#include "../sprites.h"

#include "superflash_horizontal.h"

// Functions
void cinematicFunctionSuperflash1() {
    superflash_vertical.x = player.x;
    superflash_vertical.y = player.y;
    superflash_vertical.width = 9;
    superflash_vertical.height = 16;
    superflash_vertical.sprite = Sprite_Superflash_1;
}

void cinematicFunctionSuperflash2() {
    superflash_vertical.width = 18;
    superflash_vertical.height = 32;
    superflash_vertical.sprite = Sprite_Superflash_2;
}

void cinematicFunctionSuperflash3() {
    superflash_vertical.width = 9;
    superflash_vertical.height = 48;
    superflash_vertical.sprite = Sprite_Superflash_3;
}

void cinematicFunctionSuperflash4() {
    superflash_vertical.width = 9;
    superflash_vertical.height = 24;
    superflash_vertical.sprite = Sprite_Superflash_4;
}

void cinematicFunctionSuperflash5() {
    superflash_vertical.width = 7;
    superflash_vertical.height = 12;
    superflash_vertical.sprite = Sprite_Superflash_5;
}

void cinematicFunctionSuperflash6() {
    superflash_vertical.width = 5;
    superflash_vertical.height = 12;
    superflash_vertical.sprite = Sprite_Superflash_6;
}

void cinematicFunctionSuperflashVerticalCleanup() {
    superflash_vertical.x = 200;
    superflash_vertical.y = 200;
    superflash_vertical.width = 1;
    superflash_vertical.height = 1;
    superflash_vertical.sprite = Sprite_None;
}

// Data
Cinematic CINEMATIC_SUPERFLASH_VERTICAL_CLEANUP = {
    totalFrames: 1,
    cinematicFunction: cinematicFunctionSuperflashVerticalCleanup,
    nextCinematic: &CINEMATIC_Sprite_Superflash_1_Horizontal
};

Cinematic CINEMATIC_SUPERFLASH_6 = {
    totalFrames: 5,
    cinematicFunction: cinematicFunctionSuperflash6,
    nextCinematic: &CINEMATIC_SUPERFLASH_VERTICAL_CLEANUP
};

Cinematic CINEMATIC_SUPERFLASH_5 = {
    totalFrames: 1,
    cinematicFunction: cinematicFunctionSuperflash5,
    nextCinematic: &CINEMATIC_SUPERFLASH_6
};

Cinematic CINEMATIC_SUPERFLASH_4 = {
    totalFrames: 2,
    cinematicFunction: cinematicFunctionSuperflash4,
    nextCinematic: &CINEMATIC_SUPERFLASH_5
};

Cinematic CINEMATIC_SUPERFLASH_3 = {
    totalFrames: 3,
    cinematicFunction: cinematicFunctionSuperflash3,
    nextCinematic: &CINEMATIC_SUPERFLASH_4
};

Cinematic CINEMATIC_SUPERFLASH_2 = {
    totalFrames: 3,
    cinematicFunction: cinematicFunctionSuperflash2,
    nextCinematic: &CINEMATIC_SUPERFLASH_3
};

Cinematic CINEMATIC_SUPERFLASH_1 = {
    totalFrames: 3,
    cinematicFunction: cinematicFunctionSuperflash1,
    nextCinematic: &CINEMATIC_SUPERFLASH_2
};

#ifdef __cplusplus
} // extern "C"
#endif

#endif
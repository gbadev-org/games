#ifndef ENGINE_CPP
#define ENGINE_CPP

#include <stddef.h>

#include "buffer.h"
#include "cinematics/cinematic.h"
#include "cinematics/superflash_vertical.h"
#include "dummy.h"
#include "engine.h"
#include "hitbox.h"
#include "input.h"
#include "knockbackData.h"
#include "move.h"
#include "moveData.h"
#include "player.h"
#include "projectile.h"
#include "renderEffect.h"
#include "sprites.h"


// Vars
uint8_t input = 0x00;
uint8_t inputCurrentFrame = 0x00;
uint8_t inputPrevFrame = 0x00;

uint16_t comboCounter = 0;
uint16_t comboCounterDisplay = 0;
uint8_t comboDisplayTimerLimit = 120;
uint8_t comboDisplayTimer = 120;

uint16_t comboDamage = 0;
uint16_t comboDamageDisplay = 0;
uint8_t comboDamageScale = 100; // in percent

uint16_t currentHitDamage = 0;

uint8_t hitStunDecay = 0;

uint8_t hitStopFrames = 0;

bool didPlayerHitMoveThisFrame = false;

Player player = {
    x: 32,
    y: 64 - 25,
    xOffset: 0,
    yOffset: 0,
    direction: true,
    currentMove: NULL,
    currentMoveFrameCounter: 0,
    currentMoveHit: false,
    state: PlayerState_Idle,
    crouchFrame: 0,
    walkFrame: 0,
    jumpFrame: 0,
    jumpDirection: 0,
    doubleJumpUsed: false,
    allowDoubleJump: true,
    renderEffect: RenderEffect_None,
    crouchState: PlayerCrouchState_Standing,
    sprite: Sprite_Player_Idle,
    hitbox: {
        x: PLAYER_HITBOX_X_OFFSET,
        y: PLAYER_HITBOX_Y_OFFSET,
        width: 10,
        height: 19
    }
};

Dummy dummy = {
    x: 64,
    y: 64 - 17,
    stunnedFrames: 0,
    recoveryFrames: 0,
    knockbackTick: 0,
    state: DummyState_Idle,
    sprite: Sprite_Dummy_Idle,
    hitbox: {
        x: 96,
        y: 64 - 17,
        width: 16,
        height: 16
    },
    knockback: KNOCKBACK_DEFAULT_INITIALIZER
};

Particle superflash_vertical = {
    x: 200,
    y: 200,
    width: 1,
    height: 1,
    sprite: Sprite_None
};

Particle superflash_horizontal = {
    x: 200,
    y: 200,
    width: 1,
    height: 1,
    sprite: Sprite_None
};

void resetGame() {
    // Initialize vars
    comboCounter = 0;
    comboCounterDisplay = 0;
    comboDisplayTimerLimit = 120;
    comboDisplayTimer = comboDisplayTimerLimit;

    comboDamage = 0;
    comboDamageDisplay = 0;
    comboDamageScale = 100; // in percent

    currentHitDamage = 0;

    hitStunDecay = 0;

    hitStopFrames = 0;

    inputPrevFrame = 0x00;

    didPlayerHitMoveThisFrame = false;

    currentCinematic = NULL;
    currentCinematicFrame = 0;

    // Reset Player
    player.x = 32;
    player.y = 64 - 25;
    player.xOffset = 0;
    player.yOffset = 0;
    player.direction = true;
    player.currentMove = NULL;
    player.currentMoveFrameCounter = 0;
    player.currentMoveHit = false;
    player.state = PlayerState_Idle;
    player.crouchFrame = 0;
    player.walkFrame = 0;
    player.jumpFrame = 0;
    player.jumpDirection = 0;
    player.doubleJumpUsed = false;
    player.allowDoubleJump = true;
    player.crouchState = PlayerCrouchState_Standing;
    player.sprite = Sprite_Player_Idle;
    player.renderEffect = RenderEffect_None;

    player.hitbox.x = PLAYER_HITBOX_X_OFFSET;
    player.hitbox.y = PLAYER_HITBOX_Y_OFFSET;
    player.hitbox.width = 10;
    player.hitbox.height = 19;

    // Reset Dummy
    dummy.x = 64;
    dummy.y = 64 - 17;
    dummy.stunnedFrames = 0;
    dummy.recoveryFrames = 0;
    dummy.knockbackTick = 0;
    dummy.state = DummyState_Idle;
    dummy.sprite = Sprite_Dummy_Idle;

    dummy.hitbox.x = 96;
    dummy.hitbox.y = 64 - 17;
    dummy.hitbox.width = 16;
    dummy.hitbox.height = 16;

    dummy.knockback.horizontalDistance = knockback_default.horizontalDistance;
    dummy.knockback.verticalDistance = knockback_default.verticalDistance;
    dummy.knockback.ticksPerFrame = knockback_default.ticksPerFrame;
    dummy.knockback.tickLimit = knockback_default.tickLimit;
    dummy.knockback.properties = knockback_default.properties;
    dummy.knockback.knockbackFunction = knockback_default.knockbackFunction;

    // Reset Fireball
    despawnProjectile(fireballPtr);

    // Reset Superflash Vertical
    superflash_vertical.x = 200;
    superflash_vertical.y = 200;
    superflash_vertical.width = 1;
    superflash_vertical.height = 1;
    superflash_vertical.sprite = Sprite_None;

    // Reset Superflash Horizontal
    superflash_horizontal.x = 200;
    superflash_horizontal.y = 200;
    superflash_horizontal.width = 1;
    superflash_horizontal.height = 1;
    superflash_horizontal.sprite = Sprite_None;
}

uint8_t getInvertedHorizontalInput(uint8_t input) {
    uint8_t inputCopy = input;

    // Copy the value of input's left_button bit to inputCopy's right_button bit
    if (input & CB_LEFT_BUTTON)
        inputCopy = inputCopy | CB_RIGHT_BUTTON;        // Set the right_button bit to TRUE with a bitmask
    else
        inputCopy = inputCopy & (~CB_RIGHT_BUTTON);     // Set the right_button bit to FALSE with a bitmask
    
    // Do the same for the value of input's right_button bit
    if (input & CB_RIGHT_BUTTON)
        inputCopy = inputCopy | CB_LEFT_BUTTON;
    else
        inputCopy = inputCopy & (~CB_LEFT_BUTTON);
    
    return inputCopy;
}

void applyKnockback(Knockback *knockback, Dummy *dummy) {
    if (knockback->knockbackFunction != NULL) {
        knockback->knockbackFunction();
    }
    else {
        dummy->knockbackTick += knockback->ticksPerFrame;

        if (dummy->knockbackTick > knockback->tickLimit) {
            dummy->x += knockback->horizontalDistance;

            // Apply vertical knockback when the dummy is in the air or when this Knockback has the CB_KB_PROP_LAUNCH property 
            if (dummy->y < 64 - 17 || knockback->properties & CB_KB_PROP_LAUNCH)
                dummy->y -= knockback->verticalDistance;

            dummy->knockbackTick = dummy->knockbackTick % knockback->tickLimit;
        }
    }
}

// Decide's the direction which the Player will be facing during this frame
// This is done by comparing the center of the Player's Hitbox with the center of the Dummy's Hitbox
void updatePlayerDirections() {

    // Prevent the player from changing directions when they're executing a move that locks the Player's direction
    if (player.currentMove != NULL && player.currentMove->moveProperties & MoveProperty_LockDirection)
        return;

    if (player.direction && player.hitbox.x + player.hitbox.width / 2 > dummy.hitbox.x + dummy.hitbox.width / 2)
        player.direction = false;
    else if (player.hitbox.x + player.hitbox.width / 2 < dummy.hitbox.x + dummy.hitbox.width / 2 && dummy.hitbox.x < 200)   // This also takes dummy.hitbox.x underflow in consideration
        player.direction = true;
}

void handlePlayerPosition(uint8_t input) {
    PlayerWalkState playerWalkState = PlayerWalkState_Standing;

    // If the player is busy with jumping, prevent walking
    if (player.jumpFrame > 0)
        return;

    // Only allow the player to move if they're not holding down (are crouching)
    if (!(input & CB_DOWN_BUTTON) && player.state != PlayerState_ExecutingMove && player.crouchState != PlayerCrouchState_Crouching) {
        if (input & CB_RIGHT_BUTTON) {
            playerMoveForwards(&player, 1);
            playerWalkState = updatePlayerWalkFrame(&player);
        }

        if (input & CB_LEFT_BUTTON) {
            playerMoveBackwards(&player, 1);
            playerWalkState = updatePlayerWalkFrame(&player);
        }

        if (playerWalkState == PlayerWalkState_Walk1)
            player.sprite = Sprite_Player_Walk_1;
        else if (playerWalkState == PlayerWalkState_Walk2)
            player.sprite = Sprite_Player_Walk_2;
    }
}

void handlePlayerCrouching(uint8_t input) {

    if (player.currentMove == &MOVE_2A)
        player.crouchFrame = CROUCH_FRAME_LIMIT;

    if (player.state != PlayerState_Idle) {
        if (player.currentMove != &MOVE_2A) {
            player.crouchFrame = 0;
        }
        return;
    }
    
    PlayerCrouchState crouchState = getPlayerCrouchState(&player, input);

    if (crouchState == PlayerCrouchState_InBetween) 
        player.sprite = Sprite_Player_Crouch_Inbetween;
    if (crouchState == PlayerCrouchState_Crouching)
        player.sprite = Sprite_Player_Crouch;
}

void handlePlayerLanding() {
    if (player.jumpFrame > 10 && player.y >= 64 - 25) {
        player.jumpFrame = 0;
        player.doubleJumpUsed = false;

        // Cancel current move
        playerSetIdle(&player);
    }
}

void handlePlayerJumping(uint8_t input) {
    PlayerJumpState jumpState = PlayerJumpState_Standing;

    // If the player is not in a jump state, then check if they initiated a jump
    if (player.jumpFrame == 0) {
        if (input & CB_UP_BUTTON)
            jumpState = updatePlayerJumpFrame(&player);
        else
            return;
    }
    else {
        if (player.doubleJumpUsed == false && player.allowDoubleJump == true && (input & CB_UP_BUTTON) && !(inputPrevFrame & CB_UP_BUTTON)) {
            player.jumpFrame = 1;
            player.doubleJumpUsed = true;
        }

        jumpState = updatePlayerJumpFrame(&player);
    }

    if (jumpState != PlayerJumpState_Startup && player.jumpFrame % 4 > 0) {
        player.x += player.jumpDirection;
        playerSyncPositionToHitbox(&player);
    }

    switch (jumpState) {
        case PlayerJumpState_Startup : 
            player.sprite = Sprite_Player_Jump_Startup; 

            // Pick jumpDirection based on directional input
            if (input & CB_RIGHT_BUTTON)
                player.jumpDirection = 1;
            else if (input & CB_LEFT_BUTTON)
                player.jumpDirection = -1;
            else
                player.jumpDirection = 0;

            // Invert jumpDirection if the player is facing left
            if (!player.direction)
                player.jumpDirection *= -1;

            break;
        case PlayerJumpState_Ascending : 
            --player.y;
            player.sprite = Sprite_Player_Jump_Ascending;
            break;
        case PlayerJumpState_Floating : 
            //++player.x;
            player.sprite = Sprite_Player_Jump_Floating;
            break;
        case PlayerJumpState_Falling : 
            ++player.y;
            player.sprite = Sprite_Player_Jump_Falling;
            break;
    }
}

void handleInputBuffer(uint8_t input) {
    // Decide which move to execute depenging on the player's input and state
    // The Player can execute new moves if they're not currently performing a move.
    // However, they are allowed to execute a new move if their current move has hit the dummy!
    // (the Player can cancel moves on-hit)

    pushIntoBuffer(input);

    bool quarterCircleBackDetected = detectQuarterCircleBack();
    bool quarterCircleForwardDetected = detectQuarterCircleForward();

    // Check to see if the player is allowed to perform a move
    if (player.state != PlayerState_ExecutingMove || player.currentMoveHit) {
        // Only look at the A and B button and if they were pressed this frame
        uint8_t buttonsPressedThisFrame = input & (CB_A_BUTTON + CB_B_BUTTON);

        // TODO FUTURE VERSION: Read the input buffer in order to accept a button press that happened up to perhaps 3-5 frames ago (in order to create input leniency when recovering from a move)

        // Remove the button if it is held down this frame AND it was held down on the previous frame aswell 
        if (buttonsPressedThisFrame & CB_A_BUTTON && inputPrevFrame & CB_A_BUTTON)
            buttonsPressedThisFrame -= CB_A_BUTTON;
        if (buttonsPressedThisFrame & CB_B_BUTTON && inputPrevFrame & CB_B_BUTTON)
            buttonsPressedThisFrame -= CB_B_BUTTON;

        // Grounded moves
        if (player.jumpFrame == 0) {
            if (quarterCircleBackDetected && buttonsPressedThisFrame & CB_A_BUTTON)
                playerExecuteMove(&player, &MOVE_HANDSTAND_KICK);
            else if (quarterCircleBackDetected && buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_HANDSTAND_KICK);   // Temporary, will be replaced with a new move
            else if (quarterCircleForwardDetected && buttonsPressedThisFrame & CB_A_BUTTON)
                playerExecuteMove(&player, &MOVE_236A);
            else if (quarterCircleForwardDetected && buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_236A);             // Temporary, will be replaced with a new move
            else if (input & CB_DOWN_BUTTON && buttonsPressedThisFrame & CB_A_BUTTON)
                playerExecuteMove(&player, &MOVE_2A);
            else if (buttonsPressedThisFrame & CB_A_BUTTON)
                playerExecuteMove(&player, &MOVE_5A);
            else if (input & CB_DOWN_BUTTON && buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_2B);
            else if (buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_5B);
        }
        else {
            // Airborne moves
            if (quarterCircleBackDetected && buttonsPressedThisFrame & CB_A_BUTTON)
                playerExecuteMove(&player, &MOVE_J_214A);
            else if (quarterCircleBackDetected && buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_J_214A);       // Temporary, will be replaced with a new move
            else if (quarterCircleForwardDetected && buttonsPressedThisFrame & CB_A_BUTTON || quarterCircleForwardDetected && buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_J_GRAB_SUPER);
            else if (buttonsPressedThisFrame & CB_A_BUTTON)
                playerExecuteMove(&player, &MOVE_J_5A);
            else if (buttonsPressedThisFrame & CB_B_BUTTON)
                playerExecuteMove(&player, &MOVE_J_5B);
        }
    }
}

void setPlayerSprite() {
    if (player.state == PlayerState_ExecutingMove) {

        // If the move has ended, return the player to idle state
        // Else, continue executing the move
        if (player.currentMoveFrameCounter >= player.currentMove->startupFrames + player.currentMove->activeFrames + player.currentMove->recoveryFrames) {
            // Create a backup of the current move and sprite
            const Move *moveCopyPtr = player.currentMove;
            CB_Sprite spriteCopy = player.sprite;

            playerSetIdle(&player);

            // Set the player back to the sprite they were on before
            if (moveCopyPtr == &MOVE_2A)
                player.sprite = spriteCopy;
        }
        else {
            MoveState moveState = getMoveState(player.currentMove, player.currentMoveFrameCounter);

            if (moveState == MoveState_Startup)
                player.sprite = player.currentMove->startupSprite;
            else if (moveState == MoveState_Active)
                player.sprite = player.currentMove->activeSprite;
            else if (moveState == MoveState_Recovery)
                player.sprite = player.currentMove->recoverySprite;
            else if (moveState == MoveState_Finished)
                player.sprite = Sprite_Player_Idle;
            else
                player.sprite = Sprite_Player_Idle;
        }

        ++player.currentMoveFrameCounter;
    }
}

void handleProjectiles(uint8_t input) {
    if (fireballPtr->despawnAfterHitstop)
        despawnProjectile(fireballPtr);

    updateFireball(fireballPtr);
}

bool handlePlayerDummyCollision(Player *player, Dummy *dummy) {
    bool didPlayerAndDummyCollidePlayerRightSide = isPointInBox(player->hitbox.x + player->hitbox.width, player->hitbox.y, &dummy->hitbox) || isPointInBox(player->hitbox.x + player->hitbox.width, player->hitbox.y + player->hitbox.height / 2, &dummy->hitbox) || isPointInBox(player->hitbox.x + player->hitbox.width, player->hitbox.y + player->hitbox.height, &dummy->hitbox);
    bool didPlayerAndDummyCollidePlayerLeftSide = isPointInBox(player->hitbox.x, player->hitbox.y, &dummy->hitbox) || isPointInBox(player->hitbox.x, player->hitbox.y + player->hitbox.height / 2, &dummy->hitbox) || isPointInBox(player->hitbox.x, player->hitbox.y + player->hitbox.height, &dummy->hitbox);

    // Push the player left outside of the dummy if they collide
    if (didPlayerAndDummyCollidePlayerRightSide && player->direction)
        player->x = dummy->x - 17 + PLAYER_HITBOX_X_OFFSET;
    else if (didPlayerAndDummyCollidePlayerLeftSide && !player->direction)
        player->x = dummy->x + 17 - PLAYER_HITBOX_X_OFFSET;

    playerSyncPositionToHitbox(player);

    return didPlayerAndDummyCollidePlayerRightSide || didPlayerAndDummyCollidePlayerLeftSide;
}

void handleCurrentMoveHit(Move const *movePtr) {

    if (movePtr == NULL)
        movePtr = player.currentMove;
        
    player.currentMoveHit = true;

    player.allowDoubleJump = true;

    uint8_t hitstunFrames = movePtr->hitstunFrames;
    uint8_t hitstunFramesMinusDecay = hitstunFrames - hitStunDecay;
    
    // Put the dummy in hitstun (with underflow check)
    if (hitstunFramesMinusDecay > hitstunFrames)
        dummy.stunnedFrames = 2;    // underflow occured, set stunnedFrames to 2
    else
        dummy.stunnedFrames = hitstunFramesMinusDecay;
   
    // Set knockback on the dummy
    if (movePtr->knockback != NULL)
        setKnockback(movePtr->knockback);
    else
        setKnockback(&knockback_default);

    // Set hitstop
    hitStopFrames = 15;

    // Increase comboCounter
    ++comboCounter;
    comboCounterDisplay = comboCounter;

    comboDisplayTimer = 0;

    // Calculate damage and add to comboDamage
    uint16_t scaledDamage = movePtr->damage * comboDamageScale;
    comboDamage += scaledDamage;
    comboDamageDisplay = comboDamage;

    currentHitDamage = scaledDamage;

    if (comboDamageScale > 10) {
        if (comboDamageScale > 50)
            comboDamageScale -= 10;
        else
            comboDamageScale -= 5;
    }

    // Update hitStunDecay
    ++hitStunDecay;
}

void handleMoveProperties(Move const *move) {
    if (move == NULL)
        return;
    
    if (move->moveProperties & MoveProperty_LockAirDirection) {
        player.jumpDirection = player.direction ? 1 : -1;
    }
    if (move->moveProperties & MoveProperty_DoNotAllowDoubleJump) { // This doesn't do much unless handleCurrentMoveAndCollision() gets changed (currently the player always gets their double jump back)
        player.allowDoubleJump = false;
    }
}

void handleCurrentMoveAndCollision() {
    // Check if player is executing a move and if that move colides with the dummy
    if (player.state == PlayerState_ExecutingMove) {

        if (player.currentMoveFrameCounter == 1)
            handleMoveProperties(player.currentMove);
        
        // Execute a move's unique function if it has one
        if (player.currentMove->moveFunction != NULL)
            player.currentMove->moveFunction();

        if (getMoveState(player.currentMove, player.currentMoveFrameCounter) == MoveState_Active && !player.currentMoveHit) {
            
            // TODO: Move this collision detection part to it's own function for re-use?

            // Decide the x position of the Hitbox 
            uint8_t xPositionHitbox;
            if (player.direction)
                xPositionHitbox = player.x + player.currentMove->hitboxData.xOffset;
            else
                xPositionHitbox = player.x + 16 - player.currentMove->hitboxData.xOffset - player.currentMove->hitboxData.width;
            
            Hitbox playerMoveHitbox = {
                x : xPositionHitbox,
                y : player.y + player.currentMove->hitboxData.yOffset,
                width : player.currentMove->hitboxData.width,
                height : player.currentMove->hitboxData.height
            };

            dummy.hitbox.x = dummy.x;
            dummy.hitbox.y = dummy.y;

            // Collision detection between the Hitbox and the Dummy
            if (dummy.state != DummyState_Recovery && collision(&playerMoveHitbox, &dummy.hitbox)) {
                handleCurrentMoveHit(player.currentMove);
                player.sprite = player.currentMove->activeSprite;
            }
        }
    }
    else {
        player.allowDoubleJump = true;
    }

    // Perform collission detection between the Fireball and the Dummy
    if (dummy.state != DummyState_Recovery && collision(&fireballPtr->hitbox, &dummy.hitbox)) {
        handleCurrentMoveHit(&MOVE_236A);
        fireballPtr->despawnAfterHitstop = true;
    }
}

void handleKnockback() {
    // TODO: improve checks
    if (dummy.state == DummyState_Hit && dummy.knockback.horizontalDistance != 0) {
        applyKnockback(&dummy.knockback, &dummy);
    }
}

void updateDummy() {
    // Update Dummy
    if (dummy.stunnedFrames > 0) {
        dummy.state = DummyState_Hit;

        --dummy.stunnedFrames;

        if (dummy.stunnedFrames == 0) {
            dummy.state = DummyState_Recovery;
            dummy.recoveryFrames = 60;

            // Reset knockback      TODO: Maybe this should be changed to setKnockback(&knockback_default) ?
            dummy.knockback.horizontalDistance = 0;
            dummy.knockback.verticalDistance = 0;
        }
    }
    else if (dummy.recoveryFrames > 0) {
        dummy.state = DummyState_Recovery;
        --dummy.recoveryFrames;
    }
    else {
        dummy.state = DummyState_Idle;
    }

    switch (dummy.state) {
        case DummyState_Idle:
            dummy.sprite = Sprite_Dummy_Idle;
            break;
        case DummyState_Hit:
            dummy.sprite = Sprite_Dummy_Hit;
            break;
        case DummyState_Recovery:
            dummy.sprite = Sprite_Dummy_Recovery;
            break;
        default:
            dummy.sprite = Sprite_Dummy_Idle;
    }

    // Apply gravity on the dummy when is not in hitstun
    if (dummy.state != DummyState_Hit && dummy.y < 64 - DUMMY_WIDTH_HEIGHT - 1)
        dummy.y += 1;

    // Update dummy's hitbox position
    dummy.hitbox.x = dummy.x;
    dummy.hitbox.y = dummy.y;
}

void preventOutofBounds() {
    // Push player inwards towards the screen
    if (player.x > 128 + 64 || player.x == 0)
        player.x = 1;
    if (player.x > 128 - 18)
        player.x = 128 - 18;
    if (player.y > 64 + 64)
        player.y = 0;
    if (player.y > 64 - 25)
        player.y = 64 - 25;

    // Push dummy inwards towards the screen
    if (dummy.x > 128 + 64 || dummy.x == 0)
        dummy.x = 1;
    if (dummy.x > 128 - 17)
        dummy.x = 128 - 17;
    if (dummy.y > 64 + 64)
        dummy.y = 0;
    if (dummy.y > 64 - 17)
        dummy.y = 64 - 17;
}

void updateComboDisplayTimer() {
    // Update the comboDisplayTimer
    if (comboDisplayTimer < comboDisplayTimerLimit) {
        ++comboDisplayTimer;
    }

    if (dummy.state == DummyState_Idle) {
        comboCounter = 0;
        comboDamage = 0;
        comboDamageScale = 100;
        hitStunDecay = 0;
    }
}

void updateGame(uint8_t input) {

    // Remove player RenderEffect
    player.renderEffect = RenderEffect_None;

    // Handle Cinematics
    if (currentCinematic != NULL) {

        // Play cinematic
        currentCinematic->cinematicFunction();

        ++currentCinematicFrame;

        // Check if the cinematic has ended, then play the next one
        if (currentCinematic != NULL && currentCinematicFrame >= currentCinematic->totalFrames) {
            currentCinematic = currentCinematic->nextCinematic;
            currentCinematicFrame = 0;
        }

        return;
    }

    inputCurrentFrame = input;

    // Force player sprite to be idle if state is idle, just in case
    if (player.state == PlayerState_Idle) {
        player.sprite = Sprite_Player_Idle;
    }

    updatePlayerDirections();

    // Invert directions if the player is facing left
    if (!player.direction) {
        input = getInvertedHorizontalInput(input);
    }

    handleInputBuffer(input);

    if (hitStopFrames > 0) {
        --hitStopFrames;

        // Check if the player repressed up during hitstop
        // And prevent the jump startup frame from being displayed
        if (player.doubleJumpUsed == false && (input & CB_UP_BUTTON) && !(inputPrevFrame & CB_UP_BUTTON)) {
            CB_Sprite spriteCopy = player.sprite;
            handlePlayerJumping(input);
            player.sprite = spriteCopy;
        }
    }
    else {
        player.xOffset = 0;
        player.yOffset = 0;
        handlePlayerPosition(input);

        handlePlayerCrouching(input);

        handlePlayerLanding();
        handlePlayerJumping(input);

        setPlayerSprite();

        handleProjectiles(input);

        handleCurrentMoveAndCollision();

        handleKnockback();

        updateDummy();

        handlePlayerDummyCollision(&player, &dummy);

        preventOutofBounds();
        
        updateComboDisplayTimer();

        playerSyncPositionToHitbox(&player);
    }

    inputPrevFrame = input;
}

#endif
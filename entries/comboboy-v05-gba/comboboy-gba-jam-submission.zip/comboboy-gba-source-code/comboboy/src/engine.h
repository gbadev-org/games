#ifndef ENGINE_H
#define ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>

#include "dummy.h"
#include "move.h"
#include "particle.h"
#include "player.h"
#include "projectile.h"



// Functions
void updateGame(uint8_t input);
void resetGame();

// Variables
extern uint8_t inputCurrentFrame;
extern uint8_t inputPrevFrame;

extern uint16_t comboCounter;
extern uint16_t comboCounterDisplay;
extern uint8_t comboDisplayTimerLimit;
extern uint8_t comboDisplayTimer;

extern uint16_t comboDamage;
extern uint16_t comboDamageDisplay;
extern uint8_t comboDamageScale;

extern uint16_t currentHitDamage;

extern uint8_t hitStunDecay;

extern bool didPlayerHitMoveThisFrame;

extern Player player;

extern Dummy dummy;

extern Particle superflash_vertical;
extern Particle superflash_horizontal;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
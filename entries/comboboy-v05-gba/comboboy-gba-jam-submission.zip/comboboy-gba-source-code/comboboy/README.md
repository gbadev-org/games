# comboboy
A singleplayer fighting game for the arduboy. There is no AI; your goal is to get the highest combo possible on the dummy.

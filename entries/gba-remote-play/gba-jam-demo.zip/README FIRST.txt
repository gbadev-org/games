This ROM streams a video (with audio) from one GBA to another one using the Link Cable in Normal Mode.

** It can only be tested on NO$GBA or hardware **

If you use NO$GBA:

- Set `Number of Emulated Gameboys` to 2
- Set `Link Gamepaks` to `Gamepaks in all GBAs` (default)
- Set `Link Cable Type` to `Automatic` (default)
- Use `sender-and-receiver.gba`, since the emulator doesn't allow linking two different ROMs. Set the GBA at the right as the sender and the one at the left as the receiver, so it plays sound.

If you use Hardware:

- Use a GBC Link Cable, not a GBA one. Normal Mode transfers are one-way only when using GBA cables.
- You can use `sender.gba` and `receiver.gba`
- Here's a video of the demo: https://www.youtube.com/watch?v=V2r4hANl914

Source code of the main project:
  https://github.com/rodri042/gba-remote-play

Source code of the GBA Jam demo:
  https://github.com/rodri042/gba-remote-play/compare/gba-jam?expand=1

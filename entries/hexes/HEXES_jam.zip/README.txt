This is the build of the game released for GBA Jam 2022, we at Eigenlight hope you'll enjoy it.

This Demo has 4 Levels and is not fully representative of the Final Product, Which I hope to release some time next year.

Embedded GBA.Ninja template by hot_pengu and exelotl. Originally from the Varooom 3D project page.

= Objective =

The game's objective is to match the Number in the Center (Known as the Center Number) with the Target Number displayed on top, and later moved to the bottom left-corner. The Center Number is in Hexadecimal and may over-or-under flow (i.e. 255 -> 0 and vice-versa).

You can shoot your Bullets by Pressing A, they are used to hit Enemies and Modifiers. Enemies will give you extra time if you destroy them and there are Enemy varieties.

You are also showered with Modifiers, which consists of Operators (+/-/×/÷) and Numbers, that when hit, are stored into the Modifier Slots in the bottom-right corner. If you have stored both Operators and Numbers, You can press B to input and modify the value of the Center Number, You may also overwrite the existing stored Modifiers by simply hitting new ones.

= Controls =

Left and Right Pads - Steer Ship

A - Shoot Bullet

B - Input Modifiers

Start - Pause or Start Game

= Credits =

Programming by:  Kaleidosium

Music and SFX by: kathound

== Special Thanks ==

- exelotl, along with PyroPyro for Natu and XNIQ's code

- Jeti for the fonts used or derived

- Jonathan So for The Game Creator's Pack, used temporarily during development

- Mark Brown for the Developing series

- Justburner for some minor math help

= Source Code =

The source code can be found on GitHub in our organization here: https://github.com/EigenlightArts/HEXES, It is licensed under the permissive MIT License.
It's the future-past year of 2004 and space hockey pucks must fight!

Navigate a 2D battlefield and SLAM into the opposing puck as hard as possible!

Watch your rebound and watch out in general, they're trying to do the same to you!


Start Button - Start the game
D-Pad - Move cursor
A Button - Start power meter and take shot

A game by Gregor M. Cameron.

Made in C++ with the BUTANO engine by Gustavo Valiente.
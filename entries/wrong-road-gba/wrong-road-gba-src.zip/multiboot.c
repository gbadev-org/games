/*
 * File: multiboot.c
 * Date: 2019-10-16
 * Program: to include when using multiboot
 * Author: Jenswa
 * Copyright (c) 2003-2019, Johan Jansen
 * License: New BSD License, expect for data files like graphics, sounds and maps
 */

int __gba_multiboot;  // compiles for multiboot, should be patched afterwards with gbafix

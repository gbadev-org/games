Thanks for downloading GBA MMO! You can find more information about the game
on the itch.io page: https://maciel310.itch.io/gba-mmo

To play this game you will need to connect a Raspberry Pi (any version) to
a GameLink cable and run the included `host` command. Detailed instructions
can be found here: https://github.com/maciel310/gba-mmo-proxy

This game is licensed under GPLv3. The full source code can be found at
https://github.com/maciel310.

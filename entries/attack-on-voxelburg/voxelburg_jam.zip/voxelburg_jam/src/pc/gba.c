#include "gba.h"

uint16_t gba_bgpal[256], gba_objpal[256];

uint16_t gba_vram[96 * 1024];

void gba_setmode(int mode, unsigned int flags)
{
}

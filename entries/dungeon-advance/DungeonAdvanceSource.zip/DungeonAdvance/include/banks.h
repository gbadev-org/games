#ifndef BANKS_H
#define BANKS_H

extern const unsigned char bank_6_data[];
extern const unsigned char bank_7_data[];

#endif

# Changelog

## [1.1]
Fixed a bug that caused entities to be drawn incorrectly when close to a player
holding a lantern.

## [1.0]
First release of the game.

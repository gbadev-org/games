https://problemkaputt.de/gbatek.htm
https://gist.github.com/JShorthouse/bfe49cdfad126e9163d9cb30fd3bf3c2
https://www.coranac.com/tonc/text/
https://www.gamedev.net/tutorials/programming/general-and-gameplay-programming/audio-programming-on-the-gameboy-advance-part-1-r1823/
